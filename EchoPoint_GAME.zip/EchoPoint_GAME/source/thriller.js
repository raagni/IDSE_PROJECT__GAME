// ============================================================================
// ECHO POINT — psychological-thriller presentation layer (v3)
// Re-skins the tested data-science game: same puzzles and maths, new story,
// realistic-proportion animated people, cinematic scenes, rewind power.
// Names start with tz to avoid clashing with earlier scripts.
// ============================================================================
window.gzNoTufts = true;
document.title = 'Echo Point — a data thriller';

// ---------------------------------------------------------------- styles
document.head.insertAdjacentHTML('beforeend', `<style>
#gz-cut{position:fixed;inset:0;z-index:650;pointer-events:none;visibility:hidden}
#gz-cut.on{visibility:visible}
.tz-bar{position:absolute;left:0;right:0;height:0;background:#000;transition:height .55s cubic-bezier(.3,.8,.3,1)}
#gz-cut.on .tz-bar{height:10.5vh}
.tz-bar.top{top:0}.tz-bar.bot{bottom:0}
#tz-dlg{position:absolute;left:50%;top:calc(10.5vh + 14px);transform:translate(-50%,-20px);opacity:0;transition:all .35s;width:min(860px,94vw);display:flex;gap:16px;align-items:flex-start;background:linear-gradient(180deg,rgba(8,10,16,.94),rgba(4,5,9,.96));border:1px solid rgba(255,255,255,.14);border-left:3px solid #e11d48;border-radius:6px;padding:14px 18px;pointer-events:auto;cursor:pointer;color:#f1ece2;box-shadow:0 20px 50px rgba(0,0,0,.7)}
#gz-cut.on #tz-dlg{opacity:1;transform:translate(-50%,0)}
#tz-por{width:104px;height:104px;border-radius:4px;flex:none;border:1px solid rgba(255,255,255,.2);background:#111}
#tz-name{font:bold .78rem 'Courier New',monospace;letter-spacing:.25em;margin-bottom:6px}
#tz-text{font:1.08rem/1.55 Georgia,serif;min-height:3.2em}
#tz-text i{color:#cbd5e1}
#tz-more{font:.72rem 'Courier New',monospace;color:#9ca3af;text-align:right;margin-top:4px;animation:tzb 1s infinite}
@keyframes tzb{50%{opacity:.3}}
#tz-skip{position:absolute;bottom:calc(10.5vh + 12px);right:18px;pointer-events:auto;font:.75rem 'Courier New';letter-spacing:.2em;background:rgba(0,0,0,.5);color:#d1d5db;border:1px solid #4b5563;padding:5px 12px;border-radius:3px;cursor:pointer}
body.tz-cut-on #top-hud,body.tz-cut-on #bottom-hud,body.tz-cut-on #aria-bubble,body.tz-cut-on #interaction-prompt,body.tz-cut-on #dd-goal,body.tz-cut-on #controls-hint{visibility:hidden!important}
#tz-rw{position:fixed;inset:0;z-index:860;pointer-events:none;display:none;align-items:center;justify-content:center;background:repeating-linear-gradient(0deg,rgba(255,255,255,.07) 0 2px,transparent 2px 5px)}
#tz-rw.on{display:flex}
#tz-rw b{font:bold clamp(2rem,6vw,4rem) 'Courier New',monospace;color:#fff;letter-spacing:.1em;text-shadow:4px 0 rgba(255,0,90,.8),-4px 0 rgba(0,255,230,.8);animation:tzj .09s infinite}
@keyframes tzj{50%{transform:translate(3px,-2px) skewX(4deg)}}
body.tz-rewinding #app-root,body.tz-rewinding .ancient-mechanism-frame{filter:saturate(.2) contrast(1.4) hue-rotate(170deg) brightness(1.15);animation:tzj .12s infinite}
#tz-whisper{position:fixed;top:24%;left:50%;transform:translateX(-50%);z-index:640;pointer-events:none;font:italic 1.25rem Georgia,serif;color:rgba(241,236,226,.0);text-shadow:0 0 12px rgba(225,29,72,.6);transition:color 1.2s;white-space:nowrap}
#tz-whisper.on{color:rgba(241,236,226,.85)}
#dd-mission .dd-card{background:#e9e1cf;color:#1c1917;border:none;border-radius:2px;font-family:'Courier New',monospace;box-shadow:0 30px 80px rgba(0,0,0,.8);position:relative}
#dd-mission .dd-card h2{color:#7f1d1d;font-family:'Courier New',monospace;letter-spacing:.12em;text-align:left;border-bottom:2px solid #7f1d1d;padding-bottom:6px}
#dd-mission .dd-card .dd-ari{color:#1c1917!important;font-family:Georgia,serif;text-align:left}
#dd-mission .dd-card ol{color:#292524}
#dd-mission .dd-card p{color:#44403c!important}
#dd-mission .dd-card::after{content:'CASE FILE';position:absolute;top:18px;right:20px;color:rgba(185,28,28,.55);border:3px solid rgba(185,28,28,.55);padding:2px 10px;font:bold 1rem 'Courier New';transform:rotate(8deg)}
#dd-mission .dd-btn{border-color:#1c1917;color:#1c1917;background:transparent}
#dd-mission .dd-btn.main{background:#1c1917;color:#e9e1cf}
.tz-polaroid{width:230px;margin:0 auto 8px;background:#efe8da;padding:10px 10px 14px;transform:rotate(-2.5deg);box-shadow:0 10px 30px rgba(0,0,0,.6);color:#1c1917;font:italic .9rem/1.35 Georgia,serif;animation:gzrank .7s cubic-bezier(.2,.9,.3,1.3)}
.tz-polaroid .ph{height:110px;background:radial-gradient(circle at 50% 40%,#3b3f4a,#0d0f14);display:flex;align-items:center;justify-content:center;font-size:2.6rem;margin-bottom:8px;filter:sepia(.3)}
.title-monolith{background:linear-gradient(180deg,rgba(5,6,10,.55),rgba(5,6,10,.85))!important;border-color:rgba(225,29,72,.35)!important;backdrop-filter:blur(2px)}
.game-main-title{font-family:'Courier New',monospace!important;letter-spacing:.35em!important;color:#f1ece2!important;text-shadow:0 0 18px rgba(225,29,72,.55),3px 0 rgba(225,29,72,.35),-3px 0 rgba(45,212,191,.25)!important}
.game-sub-title{color:#e11d48!important;letter-spacing:.5em!important}
</style>`);
document.body.insertAdjacentHTML('beforeend', '<div id="gz-cut"><div class="tz-bar top"></div><div class="tz-bar bot"></div><button id="tz-skip">SKIP ▶▶</button><div id="tz-dlg"><canvas id="tz-por" width="208" height="208"></canvas><div style="flex:1"><div id="tz-name"></div><div id="tz-text"></div><div id="tz-more">click / E ▶</div></div></div></div><div id="tz-rw"><b>◀◀ REWIND</b></div><div id="tz-whisper"></div>');

// ---------------------------------------------------------------- helpers
const tzT = () => performance.now() / 1000;
const tzR = i => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
function tzHex(h, k) { const n = parseInt(h.slice(1), 16); const r = Math.min(255, (n >> 16) * k | 0), g = Math.min(255, ((n >> 8) & 255) * k | 0), b = Math.min(255, (n & 255) * k | 0); return 'rgb(' + r + ',' + g + ',' + b + ')'; }
const tzH = () => canvas.height * 0.205;
const tzIndoor = i => i === 0 || i === 1 || i === 2;

// ---------------------------------------------------------------- cast
const tzCast = {
  MIRA: { name: 'MIRA', col: '#f472b6', skin: '#c68a64', hair: '#1c1412', top: '#7a2b3a', pants: '#2b3550', shoes: '#e8e4da', bag: '#2f5f5a', style: 'pony' },
  ROSIE: { name: 'ROSIE', col: '#fbbf24', skin: '#e2b391', hair: '#b9b3aa', top: '#3e6d8a', apron: '#e9e2d0', pants: '#2a2a33', shoes: '#2a2222', style: 'bun' },
  HALE: { name: 'MR. HALE', col: '#f59e0b', skin: '#8a5a3c', hair: '#2a2a2a', top: '#4a5a3a', pants: '#3a4a2e', shoes: '#1a1a1a', style: 'cap', cap: '#7c2d12' },
  NOVA: { name: 'DJ NOVA', col: '#a78bfa', skin: '#6b4430', hair: '#141014', top: '#30264a', pants: '#1c1c26', shoes: '#b91c1c', style: 'afro', phones: true },
  RANGER: { name: 'RANGER COLE', col: '#4ade80', skin: '#d9a07a', hair: '#5a3a1a', top: '#3b5a3a', pants: '#4a4030', shoes: '#2a1a10', style: 'hat' },
  JUN: { name: 'JUN', col: '#60a5fa', skin: '#d8a47f', hair: '#1f1f22', top: '#2f4f7a', pants: '#2d2d33', shoes: '#d9d9d9', style: 'short' },
  STRANGER: { name: '???', col: '#e11d48', skin: '#060608', hair: '#060608', top: '#0a0a0f', pants: '#0a0a0f', shoes: '#050505', style: 'hood', coat: true, faceless: true }
};
const tzState = {};

// ---------------------------------------------------------------- the human renderer
// Side-on, ~7.5 heads tall. Legs are solved so the planted foot touches the ground,
// which gives a natural pelvis bob with no foot sliding.
function tzDrawHuman(c, x, gy, o) {
  const C = tzCast[o.cast], H = o.H || tzH(), u = H / 7.5, t = o.t != null ? o.t : tzT(), f = o.facing || 1;
  const a = o.gait || 0, ph = o.ph || 0, air = !!o.air, vy = o.vy || 0, alpha = o.alpha == null ? 1 : o.alpha;
  const st = tzState[o.key || o.cast] = tzState[o.key || o.cast] || { hairA: .3, hairV: 0, blinkT: 0 };
  const L1 = 1.95 * u, L2 = 1.9 * u, A1 = 1.4 * u, A2 = 1.3 * u;
  const leg = off => {
    if (air) return off ? [0.1, 0.9] : [0.75, 1.45];
    if (a < 0.04) { const ws = Math.sin(t * 0.7 + (o.seed || 0)) * 0.035; return off ? [-0.07 + ws, 0.1] : [0.06 + ws, 0.07]; }
    const p = ph + off * Math.PI, A = Math.min(a, 1.5);
    return [0.4 * A * Math.sin(p), 0.07 + A * (0.85 * Math.pow(Math.max(0, Math.cos(p)), 1.5) + 0.06) + (a > 1.15 ? 0.35 * Math.max(0, Math.cos(p)) : 0)];
  };
  const lg0 = leg(0), lg1 = leg(1);
  const drop = l => L1 * Math.cos(l[0]) + L2 * Math.cos(l[0] - l[1]);
  const sole = 0.22 * u;
  let hipY = air ? -(L1 + L2) * 0.93 - sole : -Math.max(drop(lg0), drop(lg1)) - sole;
  const br = Math.sin(t * 1.7 + (o.seed || 0)) * 0.035 * u;
  let lean = 0.04 * Math.min(a, 1) + (a > 1.15 ? 0.13 : 0) + (o.talk ? Math.sin(t * 2.3) * 0.03 : 0) + (o.lean || 0);
  c.save(); c.globalAlpha = alpha; c.translate(x, gy);
  if (!air && !o.noShadow) { const sg = c.createRadialGradient(0, 0, 2, 0, 0, u * 1.6); sg.addColorStop(0, 'rgba(0,0,0,.55)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = sg; c.beginPath(); c.ellipse(0, 0, u * 1.6, u * .32, 0, 0, 6.28); c.fill(); }
  c.scale(f, 1); c.lineCap = 'round'; c.lineJoin = 'round';
  const pt = (x0, y0, ang, l) => [x0 + Math.sin(ang) * l, y0 + Math.cos(ang) * l];
  const seg = (x0, y0, a1, a2, l1, l2, w1, w2, col) => {
    const k = pt(x0, y0, a1, l1), e = pt(k[0], k[1], a2, l2);
    c.strokeStyle = col; c.lineWidth = w1; c.beginPath(); c.moveTo(x0, y0); c.lineTo(k[0], k[1]); c.stroke();
    c.lineWidth = w2; c.beginPath(); c.moveTo(k[0], k[1]); c.lineTo(e[0], e[1]); c.stroke();
    return { k, e };
  };
  const shoe = (e, ang, col, sole2, p) => {
    c.save(); c.translate(e[0], e[1]);
    let rot = 0; if (!air && a > 0.04) rot = -0.32 * Math.max(0, Math.cos(p)) * Math.min(a, 1.3) + 0.22 * Math.max(0, -Math.sin(p - 0.4)) * Math.min(a, 1.3) * (Math.cos(p) < 0 ? 1 : 0); if (air) rot = -0.3;
    c.rotate(rot); c.fillStyle = col; c.beginPath(); c.moveTo(-0.28 * u, -0.25 * u); c.lineTo(0.35 * u, -0.22 * u); c.quadraticCurveTo(0.85 * u, -0.12 * u, 0.85 * u, 0.12 * u); c.lineTo(-0.3 * u, 0.12 * u); c.closePath(); c.fill();
    c.fillStyle = sole2; c.fillRect(-0.3 * u, 0.06 * u, 1.15 * u, 0.1 * u); c.restore();
  };
  const arm = off => {
    if (o.flash && off === 0) return [1.1, 0.3];
    if (o.talk && off === 0) return [0.45 + 0.28 * Math.sin(t * 3.1), 1.35 + 0.25 * Math.sin(t * 4.7)];
    if (o.pose === 'phone' && off === 0) return [0.55, 2.2];
    if (air) return off ? [-0.5, 0.7] : [-0.9, 0.8];
    if (a < 0.04) return [off ? -0.05 : 0.05, 0.14 + Math.sin(t * 1.7) * 0.02];
    const p = ph + off * Math.PI, A = Math.min(a, 1.5);
    return [-0.36 * A * Math.sin(p), (a > 1.15 ? 1.35 : 0.22) + 0.3 * A * Math.max(0, -Math.sin(p))];
  };
  const sx = Math.sin(lean) * 2.15 * u, sy = hipY - Math.cos(lean) * 2.15 * u + br;
  const shX = sx - 0.05 * u, shY = sy + 0.18 * u;
  const pantsF = tzHex(C.pants, .68), topF = tzHex(C.top, .62), skinF = tzHex(C.skin, .75);
  // far arm + far leg
  const am1 = arm(1); const fa = seg(shX - 0.1 * u, shY, am1[0], am1[0] + am1[1], A1, A2, 0.3 * u, 0.25 * u, topF);
  c.fillStyle = skinF; c.beginPath(); c.arc(fa.e[0], fa.e[1], 0.15 * u, 0, 6.28); c.fill();
  const fl = seg(-0.1 * u, hipY, lg1[0], lg1[0] - lg1[1], L1, L2, 0.44 * u, 0.33 * u, pantsF);
  shoe(fl.e, 0, tzHex(C.shoes, .7), '#9ca3af', ph + Math.PI);
  // backpack / coat back
  if (C.bag) { c.fillStyle = C.bag; c.beginPath(); c.roundRect(sx - 1.12 * u, sy + 0.25 * u, 0.62 * u, 1.7 * u, 0.22 * u); c.fill(); c.fillStyle = tzHex(C.bag, .7); c.fillRect(sx - 1.08 * u, sy + 1.2 * u, 0.5 * u, 0.12 * u); }
  if (C.coat) { const fl2 = Math.sin(t * 2) * 0.1 * u + a * 0.25 * u; c.fillStyle = '#07070b'; c.beginPath(); c.moveTo(sx - 0.55 * u, sy + 0.1 * u); c.lineTo(-0.7 * u - fl2, hipY + 2.3 * u); c.lineTo(0.2 * u, hipY + 2.3 * u); c.lineTo(0.3 * u, hipY); c.closePath(); c.fill(); }
  // near leg
  const nl = seg(0.08 * u, hipY, lg0[0], lg0[0] - lg0[1], L1, L2, 0.46 * u, 0.35 * u, C.pants);
  shoe(nl.e, 0, C.shoes, '#d1d5db', ph);
  // torso
  const hem = hipY + (C.coat ? 2.3 : 0.4) * u;
  const tg = c.createLinearGradient(sx + 0.6 * u, sy, sx - 0.6 * u, hipY); tg.addColorStop(0, tzHex(C.top, 1.25)); tg.addColorStop(1, tzHex(C.top, .8));
  c.fillStyle = C.coat ? '#0b0b10' : tg;
  c.beginPath(); c.moveTo(sx - 0.5 * u, sy + 0.05 * u);
  c.quadraticCurveTo(sx - 0.7 * u, (sy + hipY) / 2, -0.5 * u, hipY - 0.1 * u);
  c.lineTo(-0.55 * u, hem); c.lineTo((C.coat ? 0.45 : 0.52) * u, hem);
  c.quadraticCurveTo(0.5 * u, hipY - 0.6 * u, sx + 0.52 * u, sy + 0.8 * u);
  c.quadraticCurveTo(sx + 0.5 * u, sy + 0.1 * u, sx + 0.15 * u, sy - 0.05 * u); c.closePath(); c.fill();
  if (!C.coat) { c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 1; c.beginPath(); c.moveTo(-0.1 * u, hipY - 0.55 * u); c.lineTo(0.42 * u, hipY - 0.55 * u); c.stroke(); }
  if (C.apron) { c.fillStyle = C.apron; c.beginPath(); c.moveTo(sx + 0.25 * u, sy + 0.6 * u); c.lineTo(sx + 0.55 * u, sy + 0.75 * u); c.lineTo(0.62 * u, hipY + 1.3 * u); c.lineTo(0.05 * u, hipY + 1.3 * u); c.closePath(); c.fill(); }
  if (C.style === 'pony' || C.style === 'short') { c.fillStyle = tzHex(C.top, .75); c.beginPath(); c.ellipse(sx - 0.35 * u, sy - 0.02 * u, 0.42 * u, 0.24 * u, -0.3, 0, 6.28); c.fill(); c.strokeStyle = '#e5e7eb'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(sx + 0.38 * u, sy + 0.2 * u); c.lineTo(sx + 0.42 * u, sy + 0.62 * u); c.stroke(); }
  if (C.bag) { c.strokeStyle = tzHex(C.bag, .6); c.lineWidth = 0.14 * u; c.beginPath(); c.moveTo(sx - 0.15 * u, sy + 0.05 * u); c.quadraticCurveTo(sx + 0.35 * u, sy + 0.6 * u, sx - 0.2 * u, sy + 1.45 * u); c.stroke(); }
  // neck + head
  const hx = sx + 0.14 * u + lean * 0.4 * u, hy = sy - 0.82 * u + (o.talk ? Math.sin(t * 5.3) * 0.03 * u : 0);
  c.strokeStyle = C.skin; c.lineWidth = 0.34 * u; c.beginPath(); c.moveTo(sx + 0.02 * u, sy + 0.05 * u); c.lineTo(hx - 0.05 * u, hy + 0.35 * u); c.stroke();
  const look = o.lookBack ? -1 : 1;
  c.save(); c.translate(hx, hy); c.scale(look, 1);
  if (C.style === 'hood') { c.fillStyle = '#08080c'; c.beginPath(); c.ellipse(-0.08 * u, -0.05 * u, 0.62 * u, 0.68 * u, 0, 0, 6.28); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.ellipse(0.12 * u, 0.08 * u, 0.36 * u, 0.44 * u, 0, 0, 6.28); c.fill();
    if (Math.random() > 0.03) { c.fillStyle = 'rgba(255,70,90,.75)'; c.beginPath(); c.arc(0.22 * u, -0.02 * u, 0.05 * u, 0, 6.28); c.arc(0.38 * u, -0.02 * u, 0.05 * u, 0, 6.28); c.fill(); } }
  else {
    if (C.style === 'afro') { c.fillStyle = C.hair; c.beginPath(); c.arc(-0.12 * u, -0.22 * u, 0.78 * u, 0, 6.28); c.fill(); }
    if (C.style === 'bun') { c.fillStyle = C.hair; c.beginPath(); c.arc(-0.45 * u, -0.48 * u, 0.26 * u, 0, 6.28); c.fill(); }
    // head
    const hg = c.createLinearGradient(0.5 * u, 0, -0.5 * u, 0); hg.addColorStop(0, tzHex(C.skin, 1.12)); hg.addColorStop(1, tzHex(C.skin, .85));
    c.fillStyle = hg; c.beginPath(); c.ellipse(0, 0, 0.47 * u, 0.56 * u, 0, 0, 6.28); c.fill();
    c.beginPath(); c.moveTo(0.4 * u, -0.05 * u); c.lineTo(0.56 * u, 0.12 * u); c.lineTo(0.42 * u, 0.17 * u); c.fill();
    c.fillStyle = tzHex(C.skin, .78); c.beginPath(); c.ellipse(-0.06 * u, 0.04 * u, 0.09 * u, 0.13 * u, 0, 0, 6.28); c.fill();
    st.blinkT -= 1 / 60; if (st.blinkT < -0.12) st.blinkT = 2 + Math.random() * 3.5;
    c.fillStyle = '#111';
    if (st.blinkT < 0) c.fillRect(0.18 * u, -0.06 * u, 0.16 * u, 0.025 * u); else { c.beginPath(); c.ellipse(0.27 * u, -0.06 * u, 0.055 * u, 0.07 * u, 0, 0, 6.28); c.fill(); }
    c.strokeStyle = tzHex(C.hair, 1.2); c.lineWidth = 0.05 * u; c.beginPath(); c.moveTo(0.14 * u, -0.2 * u); c.lineTo(0.38 * u, -0.19 * u); c.stroke();
    const mo = o.talk && Math.sin(t * 14) > 0 ? 0.06 * u : 0.012 * u;
    c.fillStyle = '#5b2a2a'; c.beginPath(); c.ellipse(0.32 * u, 0.3 * u, 0.08 * u, mo, 0, 0, 6.28); c.fill();
    // hair
    c.fillStyle = C.hair;
    if (C.style === 'pony' || C.style === 'short' || C.style === 'bun' || C.style === 'cap') {
      c.beginPath(); c.moveTo(0.38 * u, -0.28 * u); c.quadraticCurveTo(0.2 * u, -0.66 * u, -0.25 * u, -0.56 * u); c.quadraticCurveTo(-0.58 * u, -0.38 * u, -0.5 * u, 0.12 * u); c.quadraticCurveTo(-0.42 * u, 0.4 * u, -0.28 * u, 0.42 * u); c.quadraticCurveTo(-0.2 * u, 0.0, -0.05 * u, -0.22 * u); c.quadraticCurveTo(0.2 * u, -0.28 * u, 0.38 * u, -0.28 * u); c.fill();
      if (C.style === 'pony') { c.beginPath(); c.moveTo(0.45 * u, -0.22 * u); c.quadraticCurveTo(0.35 * u, -0.05 * u, 0.33 * u, 0.02 * u); c.lineTo(0.28 * u, -0.25 * u); c.fill(); }
    }
    if (C.style === 'pony') {
      const vx = (o.vx || 0) * f; const target = 0.35 + Math.max(-0.4, Math.min(0.9, vx * 0.09)) + (air ? -vy * 0.04 : 0) + Math.sin(t * 2.1) * 0.04 + (a > 0.04 ? Math.sin(ph * 2) * 0.12 : 0);
      st.hairV += (target - st.hairA) * 0.12; st.hairV *= 0.82; st.hairA += st.hairV;
      const ax = -0.42 * u, ay = -0.3 * u, ang = st.hairA, len = 1.25 * u;
      const ex = ax - Math.sin(ang + 0.3) * len, ey = ay + Math.cos(ang + 0.3) * len;
      c.beginPath(); c.moveTo(ax, ay - 0.1 * u); c.quadraticCurveTo(ax - 0.5 * u, ay + 0.1 * u - st.hairV * 4, ex, ey); c.quadraticCurveTo(ax - 0.2 * u, ay + 0.4 * u, ax + 0.05 * u, ay + 0.1 * u); c.fill();
      c.fillStyle = '#e11d48'; c.beginPath(); c.arc(ax - 0.02 * u, ay, 0.07 * u, 0, 6.28); c.fill();
    }
    if (C.style === 'cap') { c.fillStyle = C.cap; c.beginPath(); c.ellipse(-0.04 * u, -0.34 * u, 0.5 * u, 0.32 * u, 0, Math.PI, 0); c.fill(); c.fillRect(0.2 * u, -0.38 * u, 0.5 * u, 0.08 * u); }
    if (C.style === 'hat') { c.fillStyle = '#6b5a3a'; c.beginPath(); c.ellipse(0, -0.42 * u, 0.85 * u, 0.12 * u, 0, 0, 6.28); c.fill(); c.beginPath(); c.roundRect(-0.38 * u, -0.85 * u, 0.76 * u, 0.48 * u, 0.15 * u); c.fill(); c.fillStyle = '#3f3422'; c.fillRect(-0.38 * u, -0.5 * u, 0.76 * u, 0.08 * u); }
    if (C.phones) { c.strokeStyle = '#d4d4d8'; c.lineWidth = 0.08 * u; c.beginPath(); c.arc(-0.06 * u, -0.1 * u, 0.62 * u, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.fillStyle = '#18181b'; c.beginPath(); c.roundRect(-0.2 * u, -0.12 * u, 0.26 * u, 0.36 * u, 0.08 * u); c.fill(); c.fillStyle = '#a78bfa'; c.fillRect(-0.15 * u, -0.02 * u, 0.16 * u, 0.04 * u); }
  }
  c.restore();
  // near arm (+ flashlight / phone)
  const am0 = arm(0); const na = seg(shX + 0.1 * u, shY, am0[0], am0[0] + am0[1], A1, A2, 0.32 * u, 0.27 * u, C.coat ? '#0b0b10' : tzHex(C.top, 1.05));
  c.fillStyle = C.skin; c.beginPath(); c.arc(na.e[0], na.e[1], 0.16 * u, 0, 6.28); c.fill();
  let hand = null;
  if (o.flash) { c.save(); c.translate(na.e[0], na.e[1]); c.rotate(-(am0[0] + am0[1]) + Math.PI / 2); c.fillStyle = '#27272a'; c.fillRect(-0.1 * u, -0.1 * u, 0.55 * u, 0.2 * u); c.fillStyle = '#fef9c3'; c.fillRect(0.42 * u, -0.12 * u, 0.08 * u, 0.24 * u); c.restore(); hand = { x: x + f * na.e[0], y: gy + na.e[1], dir: f }; }
  if (o.pose === 'phone') { c.fillStyle = '#111827'; c.fillRect(na.e[0] - 0.05 * u, na.e[1] - 0.4 * u, 0.18 * u, 0.32 * u); c.fillStyle = 'rgba(147,197,253,.9)'; c.fillRect(na.e[0] - 0.02 * u, na.e[1] - 0.37 * u, 0.12 * u, 0.24 * u); }
  // rim light from the scene
  if (o.rim) { c.globalCompositeOperation = 'lighter'; c.strokeStyle = o.rim; c.lineWidth = 1.2; c.globalAlpha = alpha * .5; c.beginPath(); c.moveTo(sx + 0.52 * u, sy + 0.8 * u); c.quadraticCurveTo(0.5 * u, hipY - 0.6 * u, 0.52 * u, hem); c.stroke(); c.globalCompositeOperation = 'source-over'; }
  c.restore();
  return hand;
}

// ---------------------------------------------------------------- player
const tzP = { ph: 0, lastX: null, gait: 0, vx: 0 };
window.gzDrawPlayer = function (c, x, gy, facing, walkFrame) {
  const dx = tzP.lastX == null ? 0 : x - tzP.lastX; tzP.lastX = x;
  const H = tzH(), sp = Math.abs(dx);
  tzP.vx += (dx - tzP.vx) * 0.25;
  const target = sp < 0.3 ? 0 : Math.min(1.6, sp / 4.0);
  tzP.gait += (target - tzP.gait) * 0.18;
  tzP.ph += sp * (Math.PI * 2) / (1.45 * H);
  const lvl = gameState.currentRegion, dark = lvl === 1 || lvl === 3 || lvl === 4;
  const hand = tzDrawHuman(c, x, gy, { cast: 'MIRA', key: 'player', H, facing, gait: tzP.gait < 0.03 ? 0 : tzP.gait, ph: tzP.ph, air: !J.on, vy: J.vy, vx: tzP.vx, flash: dark && !document.body.classList.contains('tz-cut-on'), talk: tzCutSpeaker() === 'MIRA', pose: tzP.pose, rim: REALMS[lvl].palette.glow });
  if (hand) tzFlashCone(c, hand, gy);
};
function tzFlashCone(c, hand, gy) {
  const w = canvas.width, L = w * 0.42, fl = 0.92 + Math.random() * 0.08;
  c.save(); c.globalCompositeOperation = 'lighter';
  const g = c.createRadialGradient(hand.x, hand.y, 4, hand.x, hand.y, L);
  g.addColorStop(0, 'rgba(255,248,215,' + .38 * fl + ')'); g.addColorStop(.5, 'rgba(255,244,200,' + .12 * fl + ')'); g.addColorStop(1, 'rgba(255,240,190,0)');
  c.fillStyle = g; c.beginPath(); c.moveTo(hand.x, hand.y); c.lineTo(hand.x + hand.dir * L, hand.y - L * 0.16); c.lineTo(hand.x + hand.dir * L, hand.y + L * 0.36); c.closePath(); c.fill();
  const pg = c.createRadialGradient(hand.x + hand.dir * L * .45, gy, 4, hand.x + hand.dir * L * .45, gy, L * .3); pg.addColorStop(0, 'rgba(255,244,200,.16)'); pg.addColorStop(1, 'rgba(255,244,200,0)'); c.fillStyle = pg; c.beginPath(); c.ellipse(hand.x + hand.dir * L * .45, gy + 4, L * .3, 14, 0, 0, 6.28); c.fill();
  c.restore();
}

// ---------------------------------------------------------------- weather & FX state
const tzWx = { rain: [], splash: [], flash: 0, nextBolt: 0, bolt: null, glitch: 0, cameo: null, nextEvent: 0, grain: null, steam: [], lastScene: -1, cars: 0 };
for (let i = 0; i < 260; i++) tzWx.rain.push({ x: Math.random(), y: Math.random(), l: 10 + Math.random() * 16, s: 0.012 + Math.random() * 0.01 });
{ const g = document.createElement('canvas'); g.width = g.height = 160; const x = g.getContext('2d'), d = x.createImageData(160, 160); for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 26; } x.putImageData(d, 0, 0); tzWx.grain = g; }

// ---------------------------------------------------------------- scenes
function tzSky(c, w, gy, top, bot) { const g = c.createLinearGradient(0, 0, 0, gy); g.addColorStop(0, top); g.addColorStop(1, bot); c.fillStyle = g; c.fillRect(0, 0, w, gy); }
function tzPine(c, x, base, hgt, col) { c.fillStyle = col; c.beginPath(); for (let k = 0; k < 5; k++) { const y = base - hgt * (k / 5), wd = hgt * 0.32 * (1 - k / 6); c.moveTo(x - wd, y); c.lineTo(x, y - hgt * 0.32); c.lineTo(x + wd, y); } c.fill(); c.fillRect(x - hgt * .02, base - hgt * .1, hgt * .04, hgt * .1); }
function tzRainIn(c, x0, y0, w0, h0, t, n) {
  c.save(); c.beginPath(); c.rect(x0, y0, w0, h0); c.clip();
  c.strokeStyle = 'rgba(190,210,235,.35)'; c.lineWidth = 1;
  for (let i = 0; i < n; i++) { const rx = x0 + ((tzR(i) * w0 + t * 30) % w0), ry = y0 + ((tzR(i + 99) * h0 + t * 520 * (0.7 + tzR(i + 7) * .6)) % h0); c.beginPath(); c.moveTo(rx, ry); c.lineTo(rx - 3, ry + 12); c.stroke(); }
  c.fillStyle = 'rgba(200,220,240,.25)';
  for (let i = 0; i < 14; i++) { const dx = x0 + tzR(i + 300) * w0, dy = y0 + ((tzR(i + 400) * h0 + t * (12 + tzR(i) * 30)) % h0); c.beginPath(); c.ellipse(dx, dy, 1.6, 2.6, 0, 0, 6.28); c.fill(); c.fillRect(dx - .5, dy - 10, 1, 9); }
  c.restore();
}
function tzCameo(c, x, base, H, alpha) { tzDrawHuman(c, x, base, { cast: 'STRANGER', key: 'cameo', H, facing: x > canvas.width / 2 ? -1 : 1, alpha, noShadow: true }); }
function tzScene(c, ri, w, h, gy, par, t) {
  const cam = tzWx.cameo && t < tzWx.cameo.until ? tzWx.cameo : null;
  if (ri === 0) { // ---- Rosie's Diner, night, rain on the windows
    const wall = c.createLinearGradient(0, 0, 0, gy); wall.addColorStop(0, '#141b24'); wall.addColorStop(1, '#1d2430'); c.fillStyle = wall; c.fillRect(0, 0, w, gy);
    c.fillStyle = '#2a1d22'; c.fillRect(0, gy - h * .2, w, h * .2); c.fillStyle = '#7f1d1d'; c.fillRect(0, gy - h * .2, w, 4);
    const wins = [.1, .4, .7].map(fx => ({ x: fx * w - par * .2, y: h * .13, ww: w * .2, hh: h * .33 }));
    wins.forEach((W, i) => {
      const sg = c.createLinearGradient(0, W.y, 0, W.y + W.hh); sg.addColorStop(0, '#0b1220'); sg.addColorStop(1, '#1e293b'); c.fillStyle = sg; c.fillRect(W.x, W.y, W.ww, W.hh);
      c.save(); c.beginPath(); c.rect(W.x, W.y, W.ww, W.hh); c.clip();
      c.fillStyle = '#05070c'; for (let b = 0; b < 6; b++) { const bx = W.x + b * W.ww / 5 - 10, bh = W.hh * (.35 + tzR(b + i * 9) * .4); c.fillRect(bx, W.y + W.hh - bh, W.ww / 5.5, bh); }
      [['#f472b6', .2], ['#2dd4bf', .6], ['#fbbf24', .85]].forEach(([col, fx], k) => { const gx = W.x + W.ww * fx + Math.sin(t * .3 + k) * 6, gyy = W.y + W.hh * (.45 + k * .1); const g = c.createRadialGradient(gx, gyy, 1, gx, gyy, 40); g.addColorStop(0, col + '88'); g.addColorStop(1, col + '00'); c.fillStyle = g; c.fillRect(gx - 40, gyy - 40, 80, 80); });
      const carX = ((t * 260 + i * 400) % (w * 2.5)) - w * .5; const hg = c.createRadialGradient(carX, W.y + W.hh * .85, 2, carX, W.y + W.hh * .85, 70); hg.addColorStop(0, 'rgba(255,250,220,.7)'); hg.addColorStop(1, 'rgba(255,250,220,0)'); c.fillStyle = hg; c.fillRect(carX - 70, W.y + W.hh * .6, 140, 80);
      if (cam && cam.win === i) tzCameo(c, W.x + W.ww * .55, W.y + W.hh + 4, tzH() * .55, .85);
      c.restore();
      tzRainIn(c, W.x, W.y, W.ww, W.hh, t, 45);
      c.strokeStyle = '#3b2f2f'; c.lineWidth = 6; c.strokeRect(W.x, W.y, W.ww, W.hh); c.lineWidth = 3; c.beginPath(); c.moveTo(W.x + W.ww / 2, W.y); c.lineTo(W.x + W.ww / 2, W.y + W.hh); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.04)'; c.beginPath(); c.moveTo(W.x + 10, W.y); c.lineTo(W.x + 40, W.y); c.lineTo(W.x + 10, W.y + W.hh * .6); c.fill();
    });
    const on = !(Math.random() < .03 || (t % 7 > 6.7 && t % 7 < 6.85));
    c.save(); c.font = 'bold ' + Math.round(h * .045) + 'px Georgia'; c.textAlign = 'center'; c.fillStyle = on ? '#ff5fa2' : '#4a2233'; c.shadowColor = '#ff2e88'; c.shadowBlur = on ? 26 : 0; c.fillText("ROSIE'S", w * .5 - par * .2, h * .095); c.restore();
    for (let i = 0; i < 4; i++) { const lx = (i + .5) * w / 4 - par * .3; c.strokeStyle = '#111'; c.lineWidth = 2; c.beginPath(); c.moveTo(lx, 0); c.lineTo(lx, h * .06); c.stroke(); c.fillStyle = '#3f3f46'; c.beginPath(); c.moveTo(lx - 14, h * .06); c.lineTo(lx + 14, h * .06); c.lineTo(lx + 8, h * .045); c.lineTo(lx - 8, h * .045); c.fill();
      c.save(); c.globalCompositeOperation = 'lighter'; const fl = .9 + Math.sin(t * 9 + i) * .03; const g = c.createLinearGradient(0, h * .06, 0, gy); g.addColorStop(0, 'rgba(255,214,150,' + .22 * fl + ')'); g.addColorStop(1, 'rgba(255,214,150,0)'); c.fillStyle = g; c.beginPath(); c.moveTo(lx - 12, h * .06); c.lineTo(lx + 12, h * .06); c.lineTo(lx + w * .1, gy); c.lineTo(lx - w * .1, gy); c.fill(); c.restore(); }
    for (let i = 0; i < 4; i++) { const bx = (.06 + i * .25) * w - par * .25; c.fillStyle = '#5b1a24'; c.beginPath(); c.roundRect(bx, gy - h * .17, w * .06, h * .17, [12, 12, 0, 0]); c.fill(); c.fillStyle = '#3a1118'; c.fillRect(bx + w * .06, gy - h * .08, w * .07, 6); }
    c.fillStyle = '#1b1a1f'; c.fillRect(0, gy, w, h - gy);
    const tw = w / 18, rows = 4, rh = (h - gy) / rows;
    for (let r = 0; r < rows; r++) for (let k = -1; k < 20; k++) { if ((k + r) % 2) continue; const sk = (r - 1.5) * 10; c.fillStyle = '#d6d3cb18'; c.beginPath(); c.moveTo(k * tw + sk - par * .8, gy + r * rh); c.lineTo((k + 1) * tw + sk - par * .8, gy + r * rh); c.lineTo((k + 1) * tw + sk * 1.4 - par * .8, gy + (r + 1) * rh); c.lineTo(k * tw + sk * 1.4 - par * .8, gy + (r + 1) * rh); c.fill(); }
    c.save(); c.globalCompositeOperation = 'lighter'; const rg = c.createLinearGradient(0, gy, 0, h); rg.addColorStop(0, on ? 'rgba(255,95,162,.12)' : 'rgba(0,0,0,0)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = rg; c.fillRect(w * .35, gy, w * .3, h - gy); c.restore();
  } else if (ri === 1) { // ---- school basement: pipes, furnaces, failing lights
    c.fillStyle = '#16130f'; c.fillRect(0, 0, w, gy);
    c.strokeStyle = 'rgba(255,255,255,.035)'; c.lineWidth = 1; for (let y = 20; y < gy; y += 34) for (let x = ((y / 34) % 2) * 40 - par * .3; x < w; x += 80) c.strokeRect(x, y, 80, 34);
    [[.62, '#5c3a26'], [.7, '#4a4a4a'], [.18, '#6b4a2b']].forEach(([fy, col], i) => { const py = gy * fy; c.fillStyle = col; c.fillRect(0, py, w, 16 + i * 4); c.fillStyle = 'rgba(255,255,255,.08)'; c.fillRect(0, py + 2, w, 3); for (let j = 0; j < 7; j++) { const jx = ((j * 210 + i * 70) - par * .5) % (w + 100); c.fillStyle = tzHex(col, .7); c.fillRect(jx, py - 4, 14, 24 + i * 4); } });
    [.3, .64].forEach((fx, i) => { const fx0 = fx * w - par * .35, fw = w * .13, fh = gy * .5; c.fillStyle = '#26221d'; c.beginPath(); c.roundRect(fx0, gy - fh, fw, fh, [20, 20, 0, 0]); c.fill(); c.fillStyle = '#1a1714'; c.fillRect(fx0 + fw * .3, 0, fw * .4, gy - fh);
      const gl = .55 + Math.sin(t * 7 + i * 2) * .15 + Math.random() * .1; const gg = c.createRadialGradient(fx0 + fw / 2, gy - fh * .35, 4, fx0 + fw / 2, gy - fh * .35, fw * .9); gg.addColorStop(0, 'rgba(255,140,40,' + gl + ')'); gg.addColorStop(1, 'rgba(255,90,20,0)'); c.fillStyle = gg; c.fillRect(fx0 - fw * .4, gy - fh, fw * 1.8, fh);
      c.fillStyle = '#0d0b09'; for (let g = 0; g < 5; g++) c.fillRect(fx0 + fw * .2, gy - fh * .5 + g * 9, fw * .6, 4);
      if (Math.random() < .2) tzWx.steam.push({ x: fx0 + fw * .5 + (Math.random() - .5) * 20, y: gy - fh, r: 6, a: .25 }); });
    tzWx.steam.forEach(s => { s.y -= .6; s.x += Math.sin(t + s.y * .02) * .3; s.r += .25; s.a -= .003; c.fillStyle = 'rgba(200,200,200,' + Math.max(0, s.a * .4) + ')'; c.beginPath(); c.arc(s.x, s.y, s.r, 0, 6.28); c.fill(); }); tzWx.steam = tzWx.steam.filter(s => s.a > 0);
    for (let i = 0; i < 3; i++) { const lx = (i + .5) * w / 3 - par * .3, on = !((t * (1.3 + i)) % 4 > 3.6 && Math.random() < .7); c.fillStyle = on ? '#e5f3ff' : '#3a3f45'; c.fillRect(lx - 50, 8, 100, 6); if (on) { c.save(); c.globalCompositeOperation = 'lighter'; const g = c.createLinearGradient(0, 14, 0, gy); g.addColorStop(0, 'rgba(200,230,255,.16)'); g.addColorStop(1, 'rgba(200,230,255,0)'); c.fillStyle = g; c.beginPath(); c.moveTo(lx - 50, 14); c.lineTo(lx + 50, 14); c.lineTo(lx + 180, gy); c.lineTo(lx - 180, gy); c.fill(); c.restore(); } }
    if (cam) tzCameo(c, cam.x, gy - h * .02, tzH() * .8, .55);
    c.fillStyle = '#1c1a17'; c.fillRect(0, gy, w, h - gy);
    for (let i = 0; i < 4; i++) { const px = tzR(i + 20) * w - par * .6, pw = 80 + tzR(i) * 120; c.fillStyle = 'rgba(120,140,160,.12)'; c.beginPath(); c.ellipse(px, gy + 20 + i * 12, pw, 7, 0, 0, 6.28); c.fill(); c.fillStyle = 'rgba(255,140,40,.1)'; c.beginPath(); c.ellipse(px + Math.sin(t) * 3, gy + 20 + i * 12, pw * .3, 3, 0, 0, 6.28); c.fill(); }
    c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(0, 0, w, h);
  } else if (ri === 2) { // ---- KECO radio studio, city in the rain
    c.fillStyle = '#17121f'; c.fillRect(0, 0, w, gy);
    for (let y = 0; y < gy * .9; y += 26) for (let x = ((y / 26) % 2) * 13 - par * .2; x < w * .5; x += 26) { c.fillStyle = 'rgba(255,255,255,.03)'; c.beginPath(); c.moveTo(x, y + 26); c.lineTo(x + 13, y); c.lineTo(x + 26, y + 26); c.fill(); }
    const W = { x: w * .5 - par * .15, y: h * .08, ww: w * .46, hh: gy * .62 };
    const sg = c.createLinearGradient(0, W.y, 0, W.y + W.hh); sg.addColorStop(0, '#0a0d1a'); sg.addColorStop(1, '#251b3a'); c.fillStyle = sg; c.fillRect(W.x, W.y, W.ww, W.hh);
    c.save(); c.beginPath(); c.rect(W.x, W.y, W.ww, W.hh); c.clip();
    for (let b = 0; b < 14; b++) { const bx = W.x + b * W.ww / 13 - 8, bh = W.hh * (.25 + tzR(b + 40) * .55); c.fillStyle = '#07060d'; c.fillRect(bx, W.y + W.hh - bh, W.ww / 15, bh); for (let k = 0; k < 10; k++) if (tzR(b * 31 + k) > .6) { c.fillStyle = tzR(b + k + Math.floor(t * .2)) > .1 ? 'rgba(255,214,120,.55)' : 'rgba(0,0,0,0)'; c.fillRect(bx + 3 + (k % 3) * 6, W.y + W.hh - bh + 8 + Math.floor(k / 3) * 12, 3, 5); } }
    const ax = W.x + W.ww * .72; c.strokeStyle = '#111'; c.lineWidth = 2; c.beginPath(); c.moveTo(ax, W.y + W.hh); c.lineTo(ax, W.y + 30); c.stroke(); if (Math.sin(t * 3) > .2) { c.fillStyle = '#ef4444'; c.shadowColor = '#ef4444'; c.shadowBlur = 14; c.beginPath(); c.arc(ax, W.y + 30, 3, 0, 6.28); c.fill(); c.shadowBlur = 0; }
    if (cam) tzCameo(c, W.x + W.ww * .3, W.y + W.hh, tzH() * .45, .7);
    c.restore(); tzRainIn(c, W.x, W.y, W.ww, W.hh, t, 70);
    c.strokeStyle = '#2b2236'; c.lineWidth = 8; c.strokeRect(W.x, W.y, W.ww, W.hh);
    const air = Math.sin(t * .7) > -0.9; c.save(); c.fillStyle = air ? '#7f1d1d' : '#2a1010'; c.beginPath(); c.roundRect(w * .12 - par * .2, h * .08, w * .14, h * .07, 6); c.fill(); c.font = 'bold ' + Math.round(h * .032) + 'px Courier New'; c.textAlign = 'center'; c.fillStyle = air ? '#fecaca' : '#4b2020'; c.shadowColor = '#ef4444'; c.shadowBlur = air ? 22 : 0; c.fillText('ON AIR', w * .19 - par * .2, h * .127); c.restore();
    const dx = w * .05 - par * .25; c.fillStyle = '#0d0b12'; c.fillRect(dx, gy - h * .1, w * .38, h * .1); c.fillStyle = '#1e1a28'; c.fillRect(dx, gy - h * .11, w * .38, h * .02);
    for (let k = 0; k < 18; k++) { c.fillStyle = Math.sin(t * 6 + k * 1.7) > .3 ? (k % 4 ? '#22c55e' : '#f59e0b') : '#14301d'; c.fillRect(dx + 14 + k * (w * .36 / 18), gy - h * .09, 5, 4); }
    c.fillStyle = '#0b0a10'; c.fillRect(dx + w * .26, gy - h * .26, w * .1, h * .12); c.strokeStyle = '#a78bfa'; c.lineWidth = 1.5; c.beginPath(); for (let k = 0; k <= 40; k++) { const xx = dx + w * .265 + k * (w * .09 / 40), yy = gy - h * .2 + Math.sin(k * .6 + t * 8) * Math.sin(k * .13 + t * 2) * h * .03; k ? c.lineTo(xx, yy) : c.moveTo(xx, yy); } c.stroke();
    c.fillStyle = '#120f18'; c.fillRect(0, gy, w, h - gy);
  } else if (ri === 3) { // ---- Hollow Woods in a storm
    tzSky(c, w, gy, '#060a10', '#152030');
    const mx = w * .72 - par * .05, my = h * .16; const mg = c.createRadialGradient(mx, my, 4, mx, my, 120); mg.addColorStop(0, 'rgba(220,230,255,.5)'); mg.addColorStop(.2, 'rgba(200,215,255,.12)'); mg.addColorStop(1, 'rgba(200,215,255,0)'); c.fillStyle = mg; c.fillRect(mx - 120, my - 120, 240, 240); c.fillStyle = '#d7deea'; c.beginPath(); c.arc(mx, my, 18, 0, 6.28); c.fill();
    for (let k = 0; k < 5; k++) { const cx = ((t * 6 * (k + 1) + k * 300) % (w + 400)) - 200; c.fillStyle = 'rgba(10,14,22,.7)'; c.beginPath(); c.ellipse(cx, h * (.1 + k * .03), 160, 26, 0, 0, 6.28); c.fill(); }
    if (tzWx.bolt && tzWx.flash > .3) { c.strokeStyle = 'rgba(230,240,255,' + tzWx.flash + ')'; c.lineWidth = 2.5; c.beginPath(); tzWx.bolt.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); }
    [[.15, '#1b2735', .62], [.35, '#121b26', .78], [.6, '#0a1018', .95]].forEach(([pf, col, sc], L) => { for (let i = 0; i < 14; i++) { const tx = ((i * w / 11 + tzR(i + L * 20) * 80 - par * pf * 3) % (w + 200)) - 100; tzPine(c, tx, gy + 4, gy * sc * (.55 + tzR(i * 3 + L) * .45), col); } if (L === 1 && cam) tzCameo(c, cam.x, gy, tzH() * .75, .7); c.fillStyle = 'rgba(40,55,75,.12)'; c.fillRect(0, gy * .45, w, gy * .55); });
    c.fillStyle = '#0d1209'; c.fillRect(0, gy, w, h - gy);
    for (let i = 0; i < 30; i++) { c.fillStyle = ['#2a1d10', '#3a2a14', '#1f2a14'][i % 3]; c.beginPath(); c.ellipse(tzR(i + 7) * w, gy + 6 + tzR(i + 70) * (h - gy - 10), 5, 2, tzR(i) * 3, 0, 6.28); c.fill(); }
  } else { // ---- the lighthouse on the cliff
    tzSky(c, w, gy, '#05070d', '#1a2336');
    for (let k = 0; k < 6; k++) { const cx = ((t * 9 * (k + 1) + k * 260) % (w + 400)) - 200; c.fillStyle = 'rgba(8,10,18,.75)'; c.beginPath(); c.ellipse(cx, h * (.08 + k * .035), 200, 30, 0, 0, 6.28); c.fill(); }
    if (tzWx.bolt && tzWx.flash > .3) { c.strokeStyle = 'rgba(230,240,255,' + tzWx.flash + ')'; c.lineWidth = 2.5; c.beginPath(); tzWx.bolt.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); }
    const hz = gy - h * .16; c.fillStyle = '#0a1422'; c.fillRect(0, hz, w, gy - hz);
    c.strokeStyle = 'rgba(160,190,220,.18)'; c.lineWidth = 1.2; for (let r = 0; r < 9; r++) { const yy = hz + r * (gy - hz) / 9 + 4; c.beginPath(); for (let x = 0; x <= w; x += 20) { const v = yy + Math.sin(x * .02 + t * (1 + r * .1) + r) * (1 + r * .4); x ? c.lineTo(x, v) : c.moveTo(x, v); } c.stroke(); }
    const lx = w * .885, top = h * .12, lw = w * .06;
    const ang = t * .9, bx = lx, by = top + 24, cs = Math.cos(ang), len = w * 1.05 * Math.abs(cs), side = cs > 0 ? -1 : 1;
    c.save(); c.globalCompositeOperation = 'lighter';
    if (len > 20) { const bg = c.createLinearGradient(bx, by, bx + side * len, by); bg.addColorStop(0, 'rgba(255,240,185,' + (.12 + .28 * Math.abs(cs)) + ')'); bg.addColorStop(1, 'rgba(255,240,185,0)'); c.fillStyle = bg; c.beginPath(); c.moveTo(bx, by - 6); c.lineTo(bx + side * len, by - 70); c.lineTo(bx + side * len, by + 150); c.lineTo(bx, by + 8); c.closePath(); c.fill(); }
    if (Math.abs(cs) < .25) { const k = 1 - Math.abs(cs) / .25, fg = c.createRadialGradient(bx, by, 2, bx, by, 220); fg.addColorStop(0, 'rgba(255,245,210,' + .9 * k + ')'); fg.addColorStop(1, 'rgba(255,245,210,0)'); c.fillStyle = fg; c.fillRect(bx - 220, by - 220, 440, 440); }
    c.restore();
    c.fillStyle = '#d6d0c4'; c.beginPath(); c.moveTo(lx - lw * .38, top + 40); c.lineTo(lx + lw * .38, top + 40); c.lineTo(lx + lw * .55, gy); c.lineTo(lx - lw * .55, gy); c.closePath(); c.fill();
    c.fillStyle = '#7f1d1d'; for (let s = 0; s < 3; s++) { const y0 = top + 70 + s * (gy - top - 70) / 3.2, y1 = y0 + 30; const k0 = (y0 - top - 40) / (gy - top - 40), k1 = (y1 - top - 40) / (gy - top - 40); c.beginPath(); c.moveTo(lx - lw * (.38 + .17 * k0), y0); c.lineTo(lx + lw * (.38 + .17 * k0), y0); c.lineTo(lx + lw * (.38 + .17 * k1), y1); c.lineTo(lx - lw * (.38 + .17 * k1), y1); c.fill(); }
    c.fillStyle = '#1f2937'; c.fillRect(lx - lw * .45, top + 6, lw * .9, 36); c.fillStyle = 'rgba(255,240,180,.9)'; c.fillRect(lx - lw * .3, top + 12, lw * .6, 22); c.fillStyle = '#111827'; c.beginPath(); c.moveTo(lx - lw * .5, top + 8); c.lineTo(lx, top - 14); c.lineTo(lx + lw * .5, top + 8); c.fill();
    if (cam) tzCameo(c, cam.x, gy, tzH() * .9, .75);
    c.fillStyle = '#121418'; c.beginPath(); c.moveTo(0, gy); for (let x = 0; x <= w; x += 30) c.lineTo(x, gy - 4 - tzR(x) * 6); c.lineTo(w, h); c.lineTo(0, h); c.fill();
    for (let i = 0; i < 9; i++) { const fx = (i + .3) * w / 9 - par * .9; c.fillStyle = '#2b2118'; c.fillRect(fx, gy - h * .055, 6, h * .055); } c.strokeStyle = 'rgba(160,130,90,.6)'; c.lineWidth = 1.5; c.beginPath(); for (let i = 0; i < 9; i++) { const fx = (i + .3) * w / 9 - par * .9 + 3; i ? c.quadraticCurveTo(fx - w / 18, gy - h * .03, fx, gy - h * .05) : c.moveTo(fx, gy - h * .05); } c.stroke();
  }
}

// ---------------------------------------------------------------- objects (evidence, notes, terminals, NPCs)
const tzStandCol = ['#4a2a2a', '#3a3128', '#2a2236', '#3a2a1a', '#2f2a26'];
drawInteractiveObject = function (c, o, sx, gy, realm, near) {
  const t = tzT(), H = tzH(), ri = gameState.currentRegion;
  if (o.type === 'npc') { const ff = explorer.x > o.x ? 1 : -1; tzDrawHuman(c, sx, gy, { cast: o.cast, key: 'npc' + ri, H: H * (o.cast === 'NOVA' ? .98 : 1), facing: ff, talk: tzCutSpeaker() === o.cast, seed: 2, rim: realm.palette.glow }); return; }
  if (o.type === 'collectible') {
    const sh = H * .32; c.fillStyle = tzStandCol[ri]; c.beginPath(); c.roundRect(sx - 22, gy - sh, 44, sh, 3); c.fill(); c.fillStyle = 'rgba(255,255,255,.06)'; c.fillRect(sx - 22, gy - sh, 44, 4);
    if (!o.collected) {
      const by = gy - sh - 6 + Math.sin(t * 2 + sx) * 1.5;
      c.save(); c.globalCompositeOperation = 'lighter'; const g = c.createRadialGradient(sx, by, 1, sx, by, near ? 46 : 30); g.addColorStop(0, realm.palette.glow + '66'); g.addColorStop(1, realm.palette.glow + '00'); c.fillStyle = g; c.fillRect(sx - 50, by - 50, 100, 100); c.restore();
      c.save(); c.translate(sx, by); c.rotate(-.12); c.fillStyle = '#efe8da'; c.fillRect(-11, -8, 22, 16); c.fillStyle = '#1f2937'; c.fillRect(-8, -5, 16, 9); c.restore();
      if (Math.sin(t * 3 + sx) > .85) { c.fillStyle = '#fff'; c.beginPath(); c.arc(sx + 8, by - 6, 1.6, 0, 6.28); c.fill(); }
    }
    return;
  }
  if (o.type === 'inscription') {
    const ph = H * .62; c.fillStyle = '#1f1b18'; c.fillRect(sx - 3, gy - ph, 6, ph);
    c.save(); c.translate(sx, gy - ph); c.rotate(Math.sin(t * .8 + sx) * .03 - .04);
    c.fillStyle = o.collected ? '#b9b2a2' : '#ece4d2'; c.fillRect(-20, -4, 40, 50); c.fillStyle = '#e11d48'; c.fillRect(-4, -6, 8, 5);
    c.strokeStyle = 'rgba(30,30,30,.55)'; c.lineWidth = 1; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(-14, 6 + i * 6); c.lineTo(10 - (i % 2) * 8, 6 + i * 6); c.stroke(); }
    if (!o.collected && near) { c.strokeStyle = realm.palette.glow; c.lineWidth = 2; c.strokeRect(-22, -6, 44, 54); }
    c.restore(); return;
  }
  if (o.type === 'mechanism') {
    const solved = o.solved, glow = solved ? '#2dd4bf' : realm.palette.glow;
    if (ri === 4) { const dw = 46, dh = H * .78; c.fillStyle = '#1a1410'; c.beginPath(); c.roundRect(sx - dw / 2, gy - dh, dw, dh, [20, 20, 0, 0]); c.fill(); c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = 'rgba(255,230,160,' + (.25 + Math.sin(t * 3) * .05) + ')'; c.fillRect(sx - 2, gy - dh + 10, 4, dh - 10); c.restore(); c.fillStyle = '#b45309'; c.beginPath(); c.arc(sx + 14, gy - dh * .45, 3, 0, 6.28); c.fill(); return; }
    const tw = 120, th = H * .36; c.fillStyle = '#18141a'; c.fillRect(sx - tw / 2, gy - th, tw, 8); c.fillRect(sx - tw / 2 + 8, gy - th, 6, th); c.fillRect(sx + tw / 2 - 14, gy - th, 6, th);
    const scrW = ri === 2 ? 110 : 60, scrH = ri === 2 ? 70 : 42, scY = gy - th - scrH - 4;
    c.fillStyle = '#0b0b10'; c.fillRect(sx - scrW / 2 - 4, scY - 4, scrW + 8, scrH + 8);
    const sc = c.createLinearGradient(0, scY, 0, scY + scrH); sc.addColorStop(0, solved ? '#064e3b' : '#0f1b2d'); sc.addColorStop(1, '#05070c'); c.fillStyle = sc; c.fillRect(sx - scrW / 2, scY, scrW, scrH);
    c.fillStyle = glow; for (let k = 0; k < (ri === 2 ? 14 : 8); k++) { const px = sx - scrW / 2 + 6 + tzR(k + ri * 5) * (scrW - 12), py = scY + 6 + tzR(k + 40) * (scrH - 12) + Math.sin(t * 2 + k) * 1.2; c.fillRect(px, py, 2.5, 2.5); }
    if (ri === 1) for (let k = 0; k < 3; k++) { c.strokeStyle = '#d4d4d8'; c.beginPath(); c.arc(sx - 30 + k * 30, gy - th + 30, 9, 0, 6.28); c.stroke(); c.beginPath(); c.moveTo(sx - 30 + k * 30, gy - th + 30); c.lineTo(sx - 30 + k * 30 + Math.cos(t * 2 + k) * 7, gy - th + 30 + Math.sin(t * 2 + k) * 7); c.stroke(); }
    c.save(); c.globalCompositeOperation = 'lighter'; const g = c.createRadialGradient(sx, scY + scrH / 2, 2, sx, scY + scrH / 2, near ? 120 : 80); g.addColorStop(0, glow + '40'); g.addColorStop(1, glow + '00'); c.fillStyle = g; c.fillRect(sx - 130, scY - 100, 260, 220); c.restore();
  }
};
// markers: verb by type, placed above head height
ddDrawMarkers = function (c, gy) {
  if (document.querySelector('.dd-overlay.on') || $d('ancient-modal').classList.contains('active') || document.body.classList.contains('tz-cut-on')) return;
  const w = canvas.width, i = gameState.currentRegion, t = performance.now(), pal = REALMS[i].palette, H = tzH();
  getRegionWorldObjects(i).forEach(o => {
    if (o.collected) return;
    const sx = o.x / 1000 * w, near = Math.abs(o.x - explorer.x) < 66;
    const k = o.type === 'npc' ? 'talk' : o.type === 'inscription' ? 'read' : o.type === 'mechanism' ? 'investigate' : 'take';
    c.save(); c.strokeStyle = near ? '#fecdd3' : pal.accent; c.lineWidth = 2; c.setLineDash([6, 5]); c.globalAlpha = .5 + .35 * Math.sin(t / 300);
    c.beginPath(); c.ellipse(sx, gy + 6, near ? 46 : 34, 8, 0, 0, 6.28); c.stroke(); c.setLineDash([]); c.globalAlpha = 1;
    const txt = near ? 'E — ' + k : k.toUpperCase(), y = gy - H - 30 + Math.sin(t / 280) * 3;
    c.font = 'bold 12px "Courier New",monospace'; const tw = c.measureText(txt).width + 18;
    c.fillStyle = near ? 'rgba(225,29,72,.92)' : 'rgba(5,6,10,.8)'; c.strokeStyle = near ? '#fecdd3' : 'rgba(255,255,255,.25)';
    c.beginPath(); c.roundRect(sx - tw / 2, y - 14, tw, 22, 3); c.fill(); c.stroke();
    c.fillStyle = '#f5f1e8'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, sx, y - 3); c.restore();
  });
};
// the moth: Mira's quiet companion
drawAriaWisp = function (c, x, y) {
  const t = tzT(), H = tzH(), yy = canvas.height * .77 - H * .82 + Math.sin(t * 1.3) * 10 + Math.sin(t * 3.7) * 3, xx = x + Math.sin(t * .9) * 12;
  c.save(); c.translate(xx, yy); c.globalCompositeOperation = 'lighter'; const g = c.createRadialGradient(0, 0, 1, 0, 0, 22); g.addColorStop(0, 'rgba(255,250,235,.35)'); g.addColorStop(1, 'rgba(255,250,235,0)'); c.fillStyle = g; c.fillRect(-22, -22, 44, 44); c.globalCompositeOperation = 'source-over';
  const fl = .25 + .75 * Math.abs(Math.sin(t * 19)); c.fillStyle = 'rgba(236,230,214,.85)';
  [-1, 1].forEach(s => { c.save(); c.scale(s, 1); c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(8 * fl + 3, -10, 12 * fl + 2, -2); c.quadraticCurveTo(7 * fl, 3, 0, 1); c.fill(); c.beginPath(); c.moveTo(0, 1); c.quadraticCurveTo(7 * fl, 8, 4 * fl, 9); c.lineTo(0, 3); c.fill(); c.restore(); });
  c.fillStyle = '#3f3a33'; c.fillRect(-1, -4, 2, 9); c.restore();
};

// ---------------------------------------------------------------- the frame: scene, actors, rain, lightning, glitch, grain
renderWorld = function () {
  const w = canvas.width, h = canvas.height, ri = gameState.currentRegion, realm = REALMS[ri], gy = h * .77, t = tzT(), par = ((explorer.x - 500) / 1000) * 60;
  const sh = gzShake.a; ctx.save(); if (sh > .3) { ctx.translate((Math.random() - .5) * sh, (Math.random() - .5) * sh); gzShake.a *= .86; } else gzShake.a = 0;
  // lightning schedule (outdoors)
  if (!tzIndoor(ri)) { if (t > tzWx.nextBolt) { tzWx.flash = 1; const bx = w * (.15 + Math.random() * .7), pts = [[bx, 0]]; let y = 0, x = bx; while (y < gy * .55) { y += 20 + Math.random() * 30; x += (Math.random() - .5) * 60; pts.push([x, y]); } tzWx.bolt = pts; tzWx.nextBolt = t + 7 + Math.random() * 12; tzThunder(); } }
  tzScene(ctx, ri, w, h, gy, par, t);
  // objects + actors
  getRegionWorldObjects(ri).forEach(o => drawInteractiveObject(ctx, o, (o.x / 1000) * w, gy, realm, activeNearestObj && activeNearestObj.id === o.id));
  if (window.tzActors) window.tzActors.forEach(a => tzDrawHuman(ctx, a.x * w, gy, { cast: a.cast, key: 'act' + a.cast, facing: a.facing, talk: tzCutSpeaker() === a.cast, seed: 5, rim: realm.palette.glow }));
  drawExplorer(ctx, (explorer.x / 1000) * w, gy, explorer.facing, explorer.walkFrame, realm.palette.accent);
  drawAriaWisp(ctx, (ariaWisp.x / 1000) * w, gy);
  // rain + splashes outdoors
  if (!tzIndoor(ri)) {
    ctx.strokeStyle = 'rgba(180,200,230,.38)'; ctx.lineWidth = 1.1; ctx.beginPath();
    tzWx.rain.forEach(d => { d.y += d.s * 1.6; d.x -= d.s * .25; if (d.y > 1) { d.y = -.05; d.x = Math.random() * 1.1; if (Math.random() < .5) tzWx.splash.push({ x: d.x * w, y: gy + Math.random() * (h - gy) * .6, r: 1, a: .5 }); } if (d.x < -.05) d.x = 1.05; const px = d.x * w, py = d.y * h; ctx.moveTo(px, py); ctx.lineTo(px - d.l * .25, py + d.l); });
    ctx.stroke();
    tzWx.splash.forEach(s => { s.r += .6; s.a -= .04; ctx.strokeStyle = 'rgba(200,215,235,' + Math.max(0, s.a) + ')'; ctx.beginPath(); ctx.ellipse(s.x, s.y, s.r * 2, s.r * .6, 0, Math.PI, 0); ctx.stroke(); }); tzWx.splash = tzWx.splash.filter(s => s.a > 0);
    ctx.fillStyle = 'rgba(2,3,6,.9)'; for (let i = 0; i < 18; i++) { const bx = (i / 17) * w - par * 1.6, bh = 20 + tzR(i + 3) * 40; ctx.beginPath(); ctx.moveTo(bx - 12, h); ctx.quadraticCurveTo(bx + Math.sin(t * 1.5 + i) * 6, h - bh, bx + 3, h - bh - 6); ctx.quadraticCurveTo(bx + 6, h - bh * .5, bx + 14, h); ctx.fill(); }
  } else { ctx.fillStyle = 'rgba(2,3,6,.85)'; ctx.beginPath(); ctx.ellipse(-par * 1.5 + w * .02, h + 20, 120, 70, 0, 0, 6.28); ctx.ellipse(w * .98 - par * 1.5, h + 30, 140, 80, 0, 0, 6.28); ctx.fill(); }
  // lightning flash
  if (tzWx.flash > 0) { ctx.fillStyle = 'rgba(220,230,255,' + tzWx.flash * .55 + ')'; ctx.fillRect(0, 0, w, h); tzWx.flash -= .06; if (tzWx.flash < 0) tzWx.flash = 0; }
  ctx.restore();
  // psychological events
  tzEvents(t, w, h, gy);
  if (t < tzWx.glitch) { for (let i = 0; i < 7; i++) { const y = Math.random() * h, hh = 4 + Math.random() * 26, dx = (Math.random() - .5) * 70; ctx.drawImage(canvas, 0, y, w, hh, dx, y, w, hh); } ctx.fillStyle = 'rgba(225,29,72,.06)'; ctx.fillRect(0, 0, w, h); }
  // cool grade + film grain
  ctx.fillStyle = 'rgba(10,20,40,.12)'; ctx.fillRect(0, 0, w, h);
  if (!gzRM()) { ctx.save(); ctx.globalAlpha = .55; const ox = Math.random() * 160, oy = Math.random() * 160; ctx.fillStyle = ctx.createPattern(tzWx.grain, 'repeat'); ctx.translate(-ox, -oy); ctx.fillRect(0, 0, w + 160, h + 160); ctx.restore(); }
};
const tzWhispers = ['you\'ve been here before', 'he\'s watching', 'check the numbers again', 'what day is it?', 'don\'t trust the average', 'you wrote that note yourself', 'it\'s not raining. is it?'];
function tzEvents(t, w, h, gy) {
  const playing = $d('top-hud').style.display === 'flex' && !document.querySelector('.dd-overlay.on') && !$d('ancient-modal').classList.contains('active') && !document.body.classList.contains('tz-cut-on');
  if (!playing) { if (!tzWx.nextEvent) tzWx.nextEvent = t + 25; return; }
  if (!tzWx.nextEvent) tzWx.nextEvent = t + 20 + Math.random() * 15;
  if (t > tzWx.nextEvent) {
    tzWx.nextEvent = t + 35 + Math.random() * 30;
    tzWx.glitch = t + .45; tzHeartbeat();
    const ri = gameState.currentRegion;
    if (Math.random() < .75) tzWx.cameo = { until: t + 1.6, x: (explorer.x > 500 ? .15 + Math.random() * .2 : .65 + Math.random() * .2) * w, win: Math.floor(Math.random() * 3) };
    if (!gzRM()) { const wh = $d('tz-whisper'); wh.textContent = tzWhispers[Math.floor(Math.random() * tzWhispers.length)]; wh.classList.add('on'); setTimeout(() => wh.classList.remove('on'), 2200); }
  }
}

// ---------------------------------------------------------------- audio: rain, drone, thunder, heartbeat, rewind
const tzAmb = { on: false };
tzAmb.start = function () {
  soundFX.init(); const A = soundFX.ctx; if (!A || tzAmb.on) return; tzAmb.on = true;
  const buf = A.createBuffer(1, A.sampleRate * 2, A.sampleRate), d = buf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  tzAmb.noise = buf;
  const src = A.createBufferSource(); src.buffer = buf; src.loop = true;
  const bp = A.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = .5;
  const lp = A.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3500;
  tzAmb.rain = A.createGain(); tzAmb.rain.gain.value = 0; src.connect(bp); bp.connect(lp); lp.connect(tzAmb.rain); tzAmb.rain.connect(A.destination); src.start();
  tzAmb.drone = A.createGain(); tzAmb.drone.gain.value = 0;
  const df = A.createBiquadFilter(); df.type = 'lowpass'; df.frequency.value = 320; df.connect(tzAmb.drone); tzAmb.drone.connect(A.destination);
  [[55, 'sawtooth'], [55.35, 'sawtooth'], [82.4, 'sine'], [130.8, 'triangle']].forEach(([f, ty]) => { const o = A.createOscillator(); o.type = ty; o.frequency.value = f; o.connect(df); o.start(); });
  const lfo = A.createOscillator(), lg = A.createGain(); lfo.frequency.value = .05; lg.gain.value = 140; lfo.connect(lg); lg.connect(df.frequency); lfo.start();
  setInterval(() => {
    const m = soundFX.muted ? 0 : 1, ri = gameState.currentRegion, title = $d('screen-title').classList.contains('active');
    const rainT = m * soundFX.musicVol * (tzIndoor(ri) ? .05 : .14) * (title ? .6 : 1), droneT = m * soundFX.musicVol * .05;
    tzAmb.rain.gain.setTargetAtTime(rainT, A.currentTime, .5); tzAmb.drone.gain.setTargetAtTime(droneT, A.currentTime, .8);
  }, 300);
};
soundFX.startAmbientLoop = function () { tzAmb.start(); };
function tzNoiseHit(dur, freq, vol, delay) { const A = soundFX.ctx; if (!A || !tzAmb.noise || soundFX.muted) return; const s = A.createBufferSource(); s.buffer = tzAmb.noise; const f = A.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq; const g = A.createGain(), n = A.currentTime + (delay || 0); g.gain.setValueAtTime(.0001, n); g.gain.exponentialRampToValueAtTime(vol * soundFX.sfxVol, n + .05); g.gain.exponentialRampToValueAtTime(.0001, n + dur); s.connect(f); f.connect(g); g.connect(A.destination); s.start(n); s.stop(n + dur + .1); }
function tzThunder() { tzNoiseHit(2.6, 180, .9, .5 + Math.random() * .8); }
function tzHeartbeat() { [0, .28, 1, 1.28].forEach((d, i) => soundFX.playTone(i % 2 ? 48 : 55, .22, 'sine', .5, d)); }
function tzRewindSound() { const A = soundFX.ctx; if (!A || soundFX.muted) return; const o = A.createOscillator(), g = A.createGain(), n = A.currentTime; o.type = 'sawtooth'; o.frequency.setValueAtTime(900, n); o.frequency.exponentialRampToValueAtTime(70, n + 1); g.gain.setValueAtTime(.0001, n); g.gain.exponentialRampToValueAtTime(.18 * soundFX.sfxVol, n + .05); g.gain.exponentialRampToValueAtTime(.0001, n + 1.1); o.connect(g); g.connect(A.destination); o.start(n); o.stop(n + 1.2); tzNoiseHit(1, 2400, .3, 0); }

// ---------------------------------------------------------------- rewinds replace hearts
gzHeartsHTML = function (pop) { let s = ''; for (let i = 0; i < gzHP.max; i++) s += '<span class="' + (i >= gzHP.h ? 'lost ' : '') + (pop && i === gzHP.h ? 'pop' : '') + '" style="color:#fda4af;font-weight:bold">⟲</span>'; return s; };
gzRedFlash = function () {
  if (gzRM()) { showToast('◀◀ Rewinding…'); return; }
  const rw = $d('tz-rw'); rw.classList.add('on'); document.body.classList.add('tz-rewinding'); tzRewindSound();
  setTimeout(() => { rw.classList.remove('on'); document.body.classList.remove('tz-rewinding'); }, 1100);
};
gzHpRender();

// ---------------------------------------------------------------- cutscenes
const tzCut = { on: false, lines: [], i: 0, typed: 0, done: null, timer: null, who: null };
function tzCutSpeaker() { return tzCut.on ? tzCut.who : null; }
function tzPlayCut(lines, done) {
  if (!lines || !lines.length) { done && done(); return; }
  explorer.movingLeft = explorer.movingRight = false; explorer.targetX = null;
  tzCut.on = true; tzCut.lines = lines; tzCut.i = 0; tzCut.done = done;
  $d('gz-cut').classList.add('on'); document.body.classList.add('tz-cut-on'); tzShowLine();
}
function tzShowLine() {
  const L = tzCut.lines[tzCut.i], C = tzCast[L.who] || tzCast.MIRA; tzCut.who = L.who; tzCut.typed = 0;
  $d('tz-name').textContent = (L.who === 'MIRA' && L.think ? 'MIRA (thinking)' : C.name); $d('tz-name').style.color = C.col;
  if (L.act) L.act();
  clearInterval(tzCut.timer); const full = L.text, el = $d('tz-text');
  tzCut.timer = setInterval(() => { tzCut.typed += 2; el.innerHTML = (L.think ? '<i>' : '') + full.slice(0, tzCut.typed) + (L.think ? '</i>' : ''); if (tzCut.typed % 6 === 0 && !soundFX.muted) soundFX.playTone(L.who === 'STRANGER' ? 90 : 520 + Math.random() * 80, .03, 'square', .04, 0); if (tzCut.typed >= full.length) clearInterval(tzCut.timer); }, 28);
}
function tzAdvance() {
  const L = tzCut.lines[tzCut.i];
  if (tzCut.typed < L.text.length) { tzCut.typed = L.text.length; clearInterval(tzCut.timer); $d('tz-text').innerHTML = (L.think ? '<i>' : '') + L.text + (L.think ? '</i>' : ''); return; }
  tzCut.i++; if (tzCut.i >= tzCut.lines.length) return tzEndCut(); tzShowLine();
}
function tzEndCut() { clearInterval(tzCut.timer); tzCut.on = false; tzCut.who = null; $d('gz-cut').classList.remove('on'); document.body.classList.remove('tz-cut-on'); const d = tzCut.done; tzCut.done = null; d && d(); }
$d('tz-dlg').onclick = () => tzAdvance();
$d('tz-skip').onclick = () => tzEndCut();
addEventListener('keydown', e => { if (!tzCut.on) return; e.stopImmediatePropagation(); e.preventDefault(); if (e.repeat) return; if ([' ', 'e', 'E', 'Enter'].includes(e.key)) tzAdvance(); else if (e.key === 'Escape') tzEndCut(); }, true);
addEventListener('pointerdown', e => { if (tzCut.on && !e.target.closest('#tz-dlg,#tz-skip')) { e.stopImmediatePropagation(); tzAdvance(); } }, true);
addEventListener('keydown', e => { if (e.key === 'Shift') window.gzRunning = true; });
addEventListener('keyup', e => { if (e.key === 'Shift') window.gzRunning = false; });
// portraits
function tzPortraitLoop() {
  const cv = $d('tz-por'); if (tzCut.on && cv) { const c = cv.getContext('2d'), who = tzCut.who || 'MIRA', C = tzCast[who] || tzCast.MIRA;
    const bg = c.createLinearGradient(0, 0, 0, 208); bg.addColorStop(0, '#1f2937'); bg.addColorStop(1, '#030407'); c.fillStyle = bg; c.fillRect(0, 0, 208, 208);
    c.save(); c.globalCompositeOperation = 'lighter'; const rim = c.createRadialGradient(170, 40, 4, 170, 40, 150); rim.addColorStop(0, C.col + '55'); rim.addColorStop(1, C.col + '00'); c.fillStyle = rim; c.fillRect(0, 0, 208, 208); c.restore();
    const typing = tzCut.typed < (tzCut.lines[tzCut.i] || { text: '' }).text.length;
    tzDrawHuman(c, 100, 640, { cast: who, key: 'por' + who, H: 590, facing: 1, talk: typing, t: tzT(), noShadow: true });
    c.fillStyle = 'rgba(0,0,0,.25)'; for (let y = 0; y < 208; y += 3) c.fillRect(0, y, 208, 1);
  }
  requestAnimationFrame(tzPortraitLoop);
}
requestAnimationFrame(tzPortraitLoop);

// ---------------------------------------------------------------- story: chapters, places, people
const tzPlaces = ["Rosie's Diner", 'Echo High — Basement', 'KECO Radio', 'Hollow Woods', 'The Lighthouse'];
const tzPal = [
  { skyTop: '#0b0f17', skyBot: '#1d2430', accent: '#f472b6', glow: '#ff5fa2', ground: '#1b1a1f' },
  { skyTop: '#16130f', skyBot: '#1c1a17', accent: '#f59e0b', glow: '#fb923c', ground: '#1c1a17' },
  { skyTop: '#17121f', skyBot: '#251b3a', accent: '#a78bfa', glow: '#c084fc', ground: '#120f18' },
  { skyTop: '#060a10', skyBot: '#152030', accent: '#4ade80', glow: '#86efac', ground: '#0d1209' },
  { skyTop: '#05070d', skyBot: '#1a2336', accent: '#fbbf24', glow: '#fde68a', ground: '#121418' }];
REALMS.forEach((r, i) => { r.name = tzPlaces[i]; r.subtitle = 'Chapter ' + (i + 1); r.palette = tzPal[i]; r.relicName = 'Clue'; });
REALMS[0].shortDesc = 'Jun\'s last hangout. The mill\'s pay flyer is lying — prove how.';
REALMS[1].shortDesc = 'Two furnaces, one lying sensor, one real danger.';
REALMS[2].shortDesc = 'A viral post from Jun\'s account — sent after he vanished.';
REALMS[3].shortDesc = 'Jun\'s phone pinged here dozens of times. Find the pattern.';
REALMS[4].shortDesc = 'Predict where the man in the coat will be. Then find Jun.';
const tzIntro = ['Rosie\'s. The last place anyone saw Jun.', 'Echo High\'s basement. Jun\'s last text just said "basement".', 'KECO Radio. Everyone in Echo Point listens to Nova.', 'Hollow Woods. Jun hated the woods.', 'The lighthouse. Every sighting of that man ends here.'];
REALMS.forEach((r, i) => r.ariaIntro = tzIntro[i]);
DD_NAMES.splice(0, 5, ...tzPlaces.map(s => s.toUpperCase()));
document.querySelector('.aria-header span').textContent = '✧ MIRA (thinking)';
{ const s = document.querySelector('.satchel-label'); if (s) s.textContent = 'Evidence:'; }
DDW.forEach(d => { d.b = []; d.p = []; });
DD_TARGET.splice(0, 5, 'Laptop', 'Furnace Control', 'Data Wall', 'Ping Map', 'Lamp Room');
DD_INTRO.splice(0, DD_INTRO.length,
  'Echo Point. It has rained for nine days straight.',
  'Five days ago my best friend Jun walked out of Rosie\'s Diner and never came home. The police say he "probably just left".',
  'Jun didn\'t just leave. He was looking into something. Numbers that didn\'t add up.',
  'And since that night, something is wrong with me. When things go badly… I can rewind. A few seconds. A few times.',
  'I\'m Mira. Every lie in this town is hiding in the data. I\'m going to find him.');
DD_SHORT[0] = ['The Blackwood Mill hiring flyer says the "average pay" is amazing. Jun circled it in red. Prove how an average can lie.', ['Talk to Rosie, pick up the 5 pay slips and read Jun\'s notebook (E).', 'At the laptop: predict, test, then decide which number is honest.', 'Wrong calls cost a rewind. You have 3.']];
DD_SHORT[1] = ['Two furnaces in the school basement. One sensor is lying, the other is warning you for real. Jun knew which.', ['Talk to Mr. Hale, grab the evidence, read both janitor logs.', 'At the furnace control: check each odd sensor\'s history and backup gauge.', 'Keep real readings, remove broken ones, run the cooling test.']];
DD_SHORT[2] = ['A viral post — "Buying ice cream makes people go swimming!" — was sent from Jun\'s account two days after he vanished. Tear it apart with data.', ['Talk to Nova, grab the evidence, read the headline printout.', 'At the Data Wall, drag dots and watch r change.', 'Open the ice cream data, add hot weather, then rate the headline.']];
DD_SHORT[3] = ['Jun\'s phone pinged from the woods dozens of times. Group the pings and decide how many places he really went.', ['Talk to Ranger Cole, collect the evidence, read the ranger note.', 'At the Ping Map, run K-means with 2, 3 and 4 groups.', 'Read the elbow chart and choose the right number of groups.']];
DD_SHORT[4] = ['The man in the long coat has been seen near the lighthouse six nights in a row. Predict where he\'ll be — and don\'t fall for the "perfect" model.', ['Read all 3 sighting logs (E).', 'In the lamp room, predict two sightings.', 'Then face the perfect-curve trap and the far-future sighting.']];
DD_HINTS[0] = ['Talk to Rosie, pick up all 5 pay slips and read Jun\'s notebook, then open the laptop.', 'Press each button. The mean uses the TOTAL of every value. What happens to a total when one giant value joins?', 'The mean gets dragged by one giant value; the median only looks at the middle. Type a big pay like 500, then pick the honest number.'];
DD_HINTS[1] = ['Read both janitor logs, then go to the furnace control panel.', 'Click the sensor marked ⚠. Did it jump suddenly, or climb step by step? Check its backup gauge.', 'Sudden jump + backup disagrees = broken, remove it. Step-by-step climb + backup agrees = real, keep it.'];
DD_HINTS[2] = ['Grab the evidence, read the headline printout, then use the Data Wall.', 'Drag one dot far away and watch r. Then open ICE CREAM & SWIMMING.', 'Press ADD HOT WEATHER. If r is weak inside each weather group, weather drives both: "confounded".'];
DD_HINTS[3] = ['Collect the evidence, read the ranger note, then open the Ping Map.', 'For 2, 3 and 4 groups: press MOVE GROUPS until the centres stop moving.', 'On the elbow chart, pick where adding one more group stops helping much.'];
DD_HINTS[4] = ['Read all 3 sighting logs, then go to the lamp room door.', 'Imagine a straight line through the dots and extend it. SHOW BEST-FIT LINE helps (counts as a hint).', 'Trust the simple line, not the curve that hits every old point. Far in the future, use the wide search zone.'];
DD_CHEER.splice(0, 5, 'The flyer was lying. Jun knew it.', 'Furnace safe. And taped under the panel: Jun\'s phone.', 'The post is fake. Someone is using Jun\'s account.', 'Three clusters. The third one is the lighthouse.', 'We know where he\'ll be. Tonight.');
DDV.L.ari = ['keep going', 'look closer', 'something\'s off here', 'evidence first'];
const tzClues = [
  ['📓', 'Jun\'s notebook: "The mill\'s average pay is a lie. If I disappear, check the school basement."'],
  ['📱', 'Jun\'s phone, taped under the furnace panel. Last note: "Sensor 9 was tampered with. KECO."'],
  ['📰', 'The viral post was sent from Jun\'s account 2 days AFTER he vanished. Someone is wearing his name.'],
  ['📍', 'Jun\'s pings form three clusters: home, school… and the old lighthouse.'],
  ['🗼', 'Your model says he\'ll be at the lighthouse tonight. So will Jun.']];
const tzNPC = [
  { cast: 'ROSIE', label: 'Talk to Rosie', lines: [{ who: 'ROSIE', text: 'Mira, honey. You look like you haven\'t slept in days.' }, { who: 'MIRA', text: 'Has anyone asked about Jun?' }, { who: 'ROSIE', text: 'Just you. He sat in that back booth every night with his laptop, glaring at the Blackwood Mill flyer. "Average my foot," he kept saying.' }, { who: 'ROSIE', text: 'His things are still scattered around. I didn\'t have the heart to clear them.' }, { who: 'MIRA', think: true, text: 'Pay slips. His notebook. The laptop. Start there.' }] },
  { cast: 'HALE', label: 'Talk to Mr. Hale', lines: [{ who: 'HALE', text: 'Basement\'s off-limits, kid.' }, { who: 'MIRA', text: 'Jun was down here the night he vanished. Please.' }, { who: 'HALE', text: '…Fine. Both furnaces have been acting strange all week. One sensor screams fire. The other… I don\'t know anymore.' }, { who: 'HALE', text: 'Jun said one of them was lying. Said you don\'t delete a number until you know WHY it\'s weird.' }] },
  { cast: 'NOVA', label: 'Talk to Nova', lines: [{ who: 'NOVA', text: 'You\'re listening to KECO, the only station still on air in this storm.' }, { who: 'NOVA', text: 'That viral post — "Buying ice cream makes people go swimming!"? It came from Jun\'s account. Two days after he went missing.' }, { who: 'MIRA', text: 'Jun would never post something that dumb.' }, { who: 'NOVA', text: 'Then prove it\'s dumb. The data\'s on the wall. Numbers don\'t lie, Mira. People who read them do.' }] },
  { cast: 'RANGER', label: 'Talk to Ranger Cole', lines: [{ who: 'RANGER', text: 'Woods are closed after dark. Storm\'s bringing trees down.' }, { who: 'MIRA', text: 'Jun\'s phone pinged out here. A lot.' }, { who: 'RANGER', text: 'County pulled the records. Dozens of pings, all over the map. Looks like noise to me.' }, { who: 'RANGER', text: 'If you can find a pattern in that mess, you\'re smarter than the county.' }, { who: 'MIRA', think: true, text: 'Noise doesn\'t cluster. Places do.' }] },
  null];
const tzOpen = [
  [{ who: 'MIRA', think: true, text: 'Rosie\'s. The last place anyone saw Jun.' }, { who: 'MIRA', think: true, text: 'If he left anything behind, it\'s here.' }],
  [{ who: 'MIRA', think: true, text: 'Echo High\'s basement. It smells like rust and something burning.' }, { who: 'MIRA', think: true, text: 'Jun\'s last text just said "basement". Nothing else.' }],
  [{ who: 'MIRA', think: true, text: 'KECO Radio. If someone\'s spreading lies in Echo Point, this is where they spread.' }],
  [{ who: 'MIRA', think: true, text: 'Hollow Woods. Jun hated the woods.' }, { who: 'MIRA', think: true, text: 'So why did his phone keep coming back here?' }],
  [{ who: 'MIRA', think: true, text: 'The lighthouse. I\'ve seen that man in the corner of my eye all week.' }, { who: 'STRANGER', text: '…' }, { who: 'MIRA', think: true, text: 'Six sightings. Six nights. There\'s a pattern. There\'s always a pattern.' }]];
// NPCs as world objects (added outside the "collect everything" rule)
const tzTalked = new Set();
{ const _g = getRegionWorldObjects; getRegionWorldObjects = function (i) { const o = _g(i); const N = tzNPC[i];
    const L = { stone_0: 'Pay Slip 1', stone_1: 'Pay Slip 2', stone_2: 'Pay Slip 3', stone_3: 'Pay Slip 4', stone_4: 'Pay Slip 5', stele_0: 'Jun\'s Notebook', altar_0: 'Back-Booth Laptop',
      crys_0: 'Jun\'s Keycard', log_a: 'Janitor Log 1', crys_1: 'Torn Photo', log_b: 'Janitor Log 2', crys_2: 'Fuse', forge_m: 'Furnace Control',
      star_0: 'Listener Letter', star_1: 'Tape Reel', stele_2: 'Headline Printout', star_2: 'Studio Key', astro_m: 'Data Wall',
      totem_0: 'Flashlight Batteries', totem_1: 'Trail Map', druid_s: 'Ranger Note', totem_2: 'Jun\'s Scarf', wilds_m: 'Ping Map',
      tab_0: 'Sighting Log 1', tab_1: 'Sighting Log 2', tab_2: 'Sighting Log 3', boss_m: 'Lamp Room' };
    o.forEach(x => { if (L[x.id]) x.label = L[x.id]; });
    if (N) o.unshift({ id: 'npc_' + i, x: 50, type: 'npc', cast: N.cast, label: N.label, collected: tzTalked.has(i), onInteract: () => tzPlayCut(N.lines, () => { tzTalked.add(i); }) });
    return o; }; }
{ const _er = enterRegion; enterRegion = function (i) { tzTalked.delete(i); tzP.lastX = null; tzWx.nextEvent = 0; _er(i); }; }
// level start: mission card → in-world opening cutscene
{ const _sm = showMission; showMission = function (i) { _sm(i); const s = $d('dd-m-start'); if (s) { s.textContent = 'BEGIN'; s.onclick = () => { ddClose('dd-mission'); tzPlayCut(tzOpen[i], () => setAriaSpeech(REALMS[i].ariaIntro, 5000)); }; } }; }
// unreliable-narrator notes: some documents are in Mira's own handwriting
{ const _a = openSunkenInscription; openSunkenInscription = function () { _a(); $d('modal-body').insertAdjacentHTML('beforeend', '<div class="ancient-carving-box" style="border-color:#e11d48"><p style="font-family:Georgia;font-style:italic;color:#fecdd3">Under Jun\'s notes, in <b>my</b> handwriting: <i>"don\'t trust the average. you\'ve told yourself this before."</i><br>I don\'t remember writing that.</p></div>'); }; }
{ const _a = openWildsInscription; openWildsInscription = function () { _a(); $d('modal-body').insertAdjacentHTML('beforeend', '<div class="ancient-carving-box" style="border-color:#e11d48"><p style="font-family:Georgia;font-style:italic;color:#fecdd3">Scrawled on the back: <i>"3rd time here. it\'s always the lighthouse. — M"</i></p></div>'); }; }
{ const _a = inspectThroneTablet; inspectThroneTablet = function (k) { _a(k); if (k === 2) $d('modal-body').insertAdjacentHTML('beforeend', '<div class="ancient-carving-box" style="border-color:#e11d48"><p style="font-family:Georgia;font-style:italic;color:#fecdd3">The last entry is in a different pen: <i>"he\'s not the one you should be afraid of."</i></p></div>'); }; }

// Learning Book → Case Notes: story text per entry
Object.assign(CODEX_ENTRIES.sunken_order, { region: tzPlaces[0], fantasyLore: 'The Blackwood Mill flyer bragged about its "average pay". The owner\'s own giant salary was in the list.' });
Object.assign(CODEX_ENTRIES.ember_outlier_error, { region: tzPlaces[1], fantasyLore: 'In Furnace 1, one sensor jumped suddenly while its backup gauge stayed normal. Someone had tampered with it.' });
Object.assign(CODEX_ENTRIES.ember_outlier_surge, { region: tzPlaces[1], fantasyLore: 'In Furnace 2, one reading climbed step by step and the backup agreed. The danger was real.' });
Object.assign(CODEX_ENTRIES.astral_correlation, { region: tzPlaces[2], title: '4. Dots that move together (correlation)', fantasyLore: 'On KECO\'s data wall, each dot is one day. Some pairs rise together, some move opposite, some have no pattern.' });
Object.assign(CODEX_ENTRIES.astral_causation, { region: tzPlaces[2], fantasyLore: 'A post from Jun\'s hijacked account claimed "Buying ice cream makes people go swimming!" Both really do rise — on hot days.' });
Object.assign(CODEX_ENTRIES.wilds_kmeans, { region: tzPlaces[3], title: '6. Grouping phone pings (clustering)', fantasyLore: 'Jun\'s phone pinged dozens of times. Grouped properly, the pings became three places.', realWorld: 'Phone companies and map apps group location pings to work out where people actually spend time.' });
Object.assign(CODEX_ENTRIES.throne_regression, { region: tzPlaces[4], title: '7. Predicting the next sighting (regression)', fantasyLore: 'The man in the coat was seen six nights in a row, a little further along the cliff each time.' });
Object.assign(CODEX_ENTRIES.throne_overfit, { region: tzPlaces[4], fantasyLore: 'A voice on the radio offered a curve that matched every past sighting exactly. It was a trap.' });

// ---------------------------------------------------------------- text re-skin for puzzle windows, overlays and messages
const tzMapG = [[/LEVEL COMPLETE!/g, 'CLUE FOUND'], [/OUT OF HEARTS 💀/g, 'THE ECHO BREAKS'], [/\bLEVEL (\d)/g, 'CHAPTER $1'], [/\bLevel (\d)/g, 'Chapter $1'],
  [/Kingdom Heart/g, 'final chapter'], [/Kingdom Map/g, 'Case Board'], [/The Learning Book/g, 'Case Notes'], [/Learning Book/g, 'Case Notes'],
  [/no hearts lost/g, 'no rewinds used'], [/HEARTS/g, 'REWINDS'], [/Hearts/g, 'Rewinds'], [/hearts/g, 'rewinds'], [/\bheart\b/g, 'rewind'], [/❤️/g, '⟲'], [/💔/g, '◀◀'],
  [/Power Crystals/g, 'Clues'], [/Power Crystal/g, 'clue'], [/Crystals/g, 'Clues'], [/\bAri\b/g, 'Mira'], [/ok that one hurt\. but every miss showed us something about the data\./g, 'the echo snapped. you can\'t rewind any further this time.']];
const tzMapR = [
  [[/The priest's poster says/g, "The mill's hiring flyer says"], [/but he sneaks his own giant pay/g, 'but the owner sneaks his own giant pay'], [/These are the gold coins 9 temple workers earned this week\./g, 'These are the monthly pay figures (₹ thousands) for 9 workers at Blackwood Mill.'], [/\bpriest's\b/g, "owner's"], [/\bpriest\b/g, 'owner'], [/\bPriest\b/g, 'Owner'], [/The pay poster/g, 'The hiring flyer'], [/\bposter\b/g, 'flyer'], [/Stone Table/g, 'Laptop'], [/Old Stone Sign/g, "Jun's Notebook"], [/OPEN THE DOOR/g, 'EXPOSE THE FLYER'], [/MEAN STONE/g, 'MEAN'], [/MEDIAN STONE/g, 'MEDIAN'], [/MODE STONE/g, 'MODE'], [/the Mean Stone/g, 'MEAN'], [/the Median Stone/g, 'MEDIAN'], [/the Mode Stone/g, 'MODE'], [/three stones/g, 'three buttons'], [/each stone/g, 'each button'], [/Three stones show/g, 'Jun wrote down'], [/Door's open\. The average got exposed\./g, 'The flyer was lying.'], [/The door opens!?/g, 'The lie is exposed.'], [/temple/g, 'mill']],
  [[/Temperature Report/g, 'Janitor Log'], [/Worker’s log/g, 'Janitor’s note'], [/Boss says/g, 'Jun told me']],
  [[/BUILD THE BRIDGE/g, 'PUBLISH THE TRUTH'], [/Build the Bridge/g, 'Publish the truth'], [/Star Map/g, 'Data Wall'], [/Headline Note/g, 'Headline Printout'], [/Pinned to a tree:/g, 'Printed out and pinned to the wall:'], [/\bstars\b/g, 'dots'], [/\bstar\b/g, 'dot'], [/\bStars\b/g, 'Dots'], [/\bStar\b/g, 'Dot'], [/\bSTAR\b/g, 'DOT'], [/\bbridge\b/g, 'story']],
  [[/Forest Map/g, 'Ping Map'], [/Nobody knows how many kinds of creature live in this forest\. Two\? Three\? Four\?/g, "Ranger's note: Jun's phone pinged from all over. Was he in two places? Three? Four?"], [/\bcreatures\b/g, 'pings'], [/\bcreature\b/g, 'ping'], [/\bCreatures\b/g, 'Pings'], [/kinds of creature/g, 'kinds of ping'], [/forest/g, 'woods']],
  [[/Dark Castle — Boss Fight/g, 'The Lighthouse — Lamp Room'], [/Teal dots = where the boss struck in attacks 1–6\. Read the pattern and survive 3 phases\. Every hit costs a rewind\./g, 'Teal dots = where the man in the coat was seen on nights 1–6 (distance along the cliff). Predict where he will be. Every miss costs a rewind.'], [/"Your boring line misses my old attacks," the boss laughs\. "My /g, 'A distorted voice cuts in on the radio: "Your boring line misses my old sightings. My '], [/The boss offers a deal/g, 'A voice on the radio'], [/The far attack/g, 'The far-future sighting'], [/BOSS DEFEATED/g, 'CAUGHT'], [/FINISH THE BOSS/g, 'GO TO THE LIGHTHOUSE'], [/The boss will strike at/g, 'He will appear at'], [/the boss got tired/gi, 'he changed his route'], [/The boss got tired and the pattern bent\./g, 'He changed his route and the pattern bent.'], [/\bboss\b/g, 'Stranger'], [/\bBoss\b/g, 'Stranger'], [/Attack (\d+) is way beyond anything we've seen \(attacks 1–6\)/g, 'Night $1 is way beyond anything we\'ve seen (nights 1–6)'], [/attack (\d+)/g, 'night $1'], [/Attack (\d+)/g, 'Night $1'], [/old attacks/g, 'old sightings'], [/\battacks\b/g, 'nights'], [/\battack\b/g, 'night'], [/It struck/g, 'He appeared at'], [/it struck/g, 'he appeared at'], [/struck/g, 'was seen at'], [/Blocked with the wide shield\./g, 'Found him with the wide search.'], [/Blocked!/g, 'Found him!'], [/✖ Hit!/g, '✖ Missed him!'], [/NARROW SHIELD/g, 'NARROW SEARCH'], [/WIDE SHIELD/g, 'WIDE SEARCH'], [/\bshield\b/g, 'search zone'], [/Shield covers/g, 'Your search covers'], [/position/g, 'spot']]];
function tzMapText(s) { let r = s; tzMapG.forEach(([a, b]) => r = r.replace(a, b)); (tzMapR[gameState.currentRegion] || []).forEach(([a, b]) => r = r.replace(a, b)); return r; }
const tzScope = '#modal-body,#modal-title,.dd-card,#relic-toast,#aria-text,#dd-banner,#dd-goal,#interaction-prompt,#screen-map,#dd-badge,#dd-lockmsg';
function tzWalk(n) { if (n.nodeType === 3) { const p = n.parentElement; if (p && p.closest(tzScope) && !p.closest('textarea,pre,script')) { const v = tzMapText(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; } return; } if (n.nodeType === 1 && !/SCRIPT|STYLE|TEXTAREA|CANVAS/.test(n.tagName)) n.childNodes.forEach(tzWalk); }
new MutationObserver(ms => { ms.forEach(m => { if (m.type === 'characterData') tzWalk(m.target); else m.addedNodes.forEach(tzWalk); }); }).observe(document.body, { childList: true, subtree: true, characterData: true });

// ---------------------------------------------------------------- level complete: the clue polaroid
{ const _slc = showLevelComplete; showLevelComplete = function (i) {
    _slc(i);
    const card = document.querySelector('#dd-complete .dd-card'), sv = $d('dd-c-crystal');
    if (sv) sv.outerHTML = '<div class="tz-polaroid"><div class="ph">' + tzClues[i][0] + '</div>' + tzClues[i][1] + '</div>';
    const h2 = card.querySelector('h2'); if (h2) h2.textContent = 'CLUE FOUND';
    const nx = card.querySelector('.dd-next'); if (nx) nx.textContent = gameState.fragmentsRecovered.every(Boolean) ? '⬇ All 5 clues found. Go to the Case Board and open the final chapter.' : '⬇ Back to the Case Board for the next chapter: ' + REALMS[Math.min(i + 1, 4)].name + '.';
    tzWalk(card);
  }; }

// ---------------------------------------------------------------- title screen
{ const m = document.querySelector('.title-monolith');
  m.querySelector('.title-crest').outerHTML = '<svg class="title-crest" viewBox="0 0 100 100" style="width:92px;height:92px"><defs><radialGradient id="tzeye"><stop offset="0" stop-color="#fecdd3"/><stop offset=".5" stop-color="#e11d48"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient></defs><circle cx="50" cy="50" r="44" fill="url(#tzeye)" opacity=".35"/><path d="M8 50 Q50 12 92 50 Q50 88 8 50Z" fill="none" stroke="#f1ece2" stroke-width="2.5"/><circle cx="50" cy="50" r="15" fill="#0b0b10" stroke="#e11d48" stroke-width="2.5"/><circle cx="50" cy="50" r="5" fill="#f1ece2"/><path d="M60 22 L64 10 M50 18 L50 6 M40 22 L36 10" stroke="#f1ece2" stroke-width="2"/></svg>';
  m.querySelector('.game-main-title').textContent = 'ECHO POINT';
  m.querySelector('.game-sub-title').textContent = 'a data thriller';
  m.querySelector('.game-tagline').innerHTML = 'Jun vanished five days ago. The numbers he left behind are lying — and so is someone in this town.<br><span style="color:#fda4af;font-style:normal;font-size:.85rem">5 chapters · 5 data mysteries · 3 rewinds per chapter</span>';
  $d('btn-begin-adventure').textContent = 'NEW GAME';
  m.lastElementChild.innerHTML = 'Walk <b>A / D</b> or <b>← →</b> · Run <b>Shift</b> · Interact <b>E</b> · Hint <b>H</b> · Headphones recommended 🎧';
  $d('controls-hint').textContent = 'Walk: A / D  •  Run: Shift  •  Jump: W  •  Interact: E  •  Hint: H  •  Pause: Esc';
}
// ---------------------------------------------------------------- case board (map)
{ const g = document.querySelector('.map-title-group'); g.querySelector('h2').textContent = 'Echo Point — Case Board'; g.querySelector('p').innerHTML = 'Pick a chapter. Solved ones get stamped. <strong id="map-progress" style="color:#fda4af;">Clues: 0 / 5</strong>';
  document.querySelectorAll('.map-lore-card div').forEach(d => { if (d.textContent === 'Crystal') d.textContent = 'Clue'; if (d.textContent === 'Story') d.textContent = 'Mira\'s note'; });
  $d('btn-restore-heart').textContent = '▶ OPEN THE FINAL CHAPTER';
  document.querySelector('.map-container').style.background = 'radial-gradient(circle at 50% 40%,#1a1512,#070605)'; }
const tzIcons = ['☕', '🔥', '📻', '🌲', '🗼'];
renderWorldMapSVG = function () {
  const svg = $d('world-map-svg'); if (!svg) return; const t = tzT();
  let h = '<defs><pattern id="tzcork" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="#6b4f36"/><circle cx="3" cy="4" r="1.2" fill="#5a412c"/><circle cx="10" cy="9" r="1" fill="#7a5b3f"/><circle cx="7" cy="13" r=".8" fill="#4e3826"/></pattern><radialGradient id="tzvig"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".7"/></radialGradient></defs><rect width="760" height="520" fill="url(#tzcork)"/>';
  h += '<g opacity=".55"><rect x="30" y="20" width="120" height="80" fill="#e9e1cf" transform="rotate(-4 90 60)"/><text x="40" y="45" font-family="Courier New" font-size="10" fill="#7f1d1d" transform="rotate(-4 90 60)">MISSING</text><text x="40" y="62" font-family="Georgia" font-size="16" fill="#111" transform="rotate(-4 90 60)">JUN PARK</text><text x="40" y="80" font-family="Courier New" font-size="8" fill="#333" transform="rotate(-4 90 60)">last seen: Rosie\'s</text></g>';
  for (let i = 0; i < REALMS.length - 1; i++) { const a = REALMS[i].mapCoords, b = REALMS[i + 1].mapCoords, on = gameState.unlockedRegions[i + 1]; h += '<path d="M' + a.x + ' ' + (a.y - 40) + ' Q ' + (a.x + b.x) / 2 + ' ' + (Math.max(a.y, b.y) - 10) + ' ' + b.x + ' ' + (b.y - 40) + '" fill="none" stroke="' + (on ? '#dc2626' : 'rgba(220,38,38,.25)') + '" stroke-width="' + (on ? 2.5 : 1.5) + '"' + (on ? '' : ' stroke-dasharray="5 5"') + '/>'; }
  REALMS.forEach((r, i) => {
    const un = gameState.unlockedRegions[i], done = gameState.fragmentsRecovered[i], sel = selectedMapRegion === i, rot = (tzR(i + 3) - .5) * 10;
    h += '<g class="map-node-group" data-region-idx="' + i + '" transform="translate(' + r.mapCoords.x + ',' + r.mapCoords.y + ') rotate(' + rot + ') scale(' + (sel ? 1.12 : 1) + ')" style="cursor:pointer">';
    h += '<rect x="-50" y="-42" width="100" height="112" fill="#000" opacity=".35" transform="translate(4,5)"/><rect class="' + (un && !done ? 'map-pulse' : '') + '" x="-50" y="-42" width="100" height="112" fill="#efe8da" stroke="' + (sel ? '#e11d48' : '#d6cfc0') + '" stroke-width="' + (sel ? 3 : 1) + '"/>';
    h += '<rect x="-42" y="-34" width="84" height="66" fill="' + r.palette.skyBot + '"/><text x="0" y="12" text-anchor="middle" font-size="30">' + tzIcons[i] + '</text>';
    h += '<text x="0" y="48" text-anchor="middle" font-family="Georgia" font-style="italic" font-size="10.5" fill="#1c1917">' + r.name.replace('Echo High — ', '') + '</text>';
    h += '<text x="0" y="62" text-anchor="middle" font-family="Courier New" font-size="8" fill="#57534e">CHAPTER ' + (i + 1) + '</text>';
    if (!un) h += '<rect x="-42" y="-34" width="84" height="66" fill="#000" opacity=".7"/><text x="0" y="6" text-anchor="middle" font-size="20">🔒</text>';
    if (done) h += '<g transform="translate(0,30) rotate(-12)"><rect x="-38" y="-14" width="76" height="22" fill="none" stroke="#b91c1c" stroke-width="2.5"/><text x="0" y="3" text-anchor="middle" font-family="Courier New" font-weight="bold" font-size="13" fill="#b91c1c">SOLVED</text></g>';
    h += '<circle cx="0" cy="-42" r="6" fill="#dc2626" stroke="#7f1d1d"/><circle cx="-2" cy="-44" r="2" fill="#fecaca"/></g>';
  });
  const n = gameState.fragmentsRecovered.filter(Boolean).length, all = n === 5;
  h += '<g id="map-heart-sanctuary" style="cursor:pointer" transform="translate(395,275) rotate(2)"><rect x="-70" y="-34" width="140" height="68" fill="' + (all ? '#fef2f2' : '#e9e1cf') + '" stroke="' + (all ? '#e11d48' : '#a8a29e') + '" stroke-width="' + (all ? 3 : 1) + '"/><text x="0" y="-10" text-anchor="middle" font-family="Courier New" font-weight="bold" font-size="13" fill="#7f1d1d">FIND JUN</text><text x="0" y="10" text-anchor="middle" font-family="Georgia" font-size="12" fill="#1c1917">' + n + ' / 5 clues</text><text x="0" y="25" text-anchor="middle" font-family="Courier New" font-size="8" fill="#57534e">' + (all ? 'click to open' : 'find every clue') + '</text><circle cx="0" cy="-34" r="5" fill="#dc2626"/></g>';
  h += '<rect width="760" height="520" fill="url(#tzvig)" pointer-events="none"/>';
  svg.innerHTML = h;
  svg.querySelectorAll('.map-node-group').forEach(el => el.addEventListener('click', () => { const idx = +el.getAttribute('data-region-idx'); soundFX.playMechanismClick(); selectMapRegion(idx); if (!gameState.unlockedRegions[idx]) ddLockedMsg(idx); }));
  const hn = svg.querySelector('#map-heart-sanctuary'); if (hn) hn.addEventListener('click', () => { if (gameState.fragmentsRecovered.every(Boolean)) openFinaleSequence(); else showToast('Find all 5 clues first.'); });
};

// ---------------------------------------------------------------- finale
openFinaleSequence = function () {
  Object.keys(CODEX_ENTRIES).forEach(k => { if (!gameState.codexUnlocked.includes(k)) gameState.codexUnlocked.push(k); }); updateTopHUD(); saveGameState();
  ['screen-map', 'screen-title'].forEach(id => $d(id).classList.remove('active')); closeAncientModal();
  gameState.currentRegion = 4; explorer.x = 520; explorer.facing = 1; ariaWisp.x = 480; gzFadeIn(); tzAmb.start();
  window.tzActors = [{ cast: 'JUN', x: .72, facing: -1 }];
  tzPlayCut([
    { who: 'MIRA', text: 'Jun?' },
    { who: 'JUN', text: 'Mira. You actually found me.' },
    { who: 'JUN', text: 'The mill was faking everything. The pay flyer, the furnace sensor, even posting as me. I hid up here with the real data.' },
    { who: 'MIRA', text: 'And the man in the coat?' },
    { who: 'JUN', text: 'The mill\'s "fixer". He\'s been out there every night… right where your line said he\'d be. The police have him now.' },
    { who: 'MIRA', text: 'I kept rewinding, Jun. Over and over. I found notes in my own handwriting I don\'t remember writing.' },
    { who: 'JUN', text: '…Mira. What day do you think it is?' }
  ], () => {
    window.tzActors = null; tzWx.glitch = tzT() + 1.2; tzHeartbeat(); soundFX.playVictory();
    const res = gzRes().best || {}, ranks = [0, 1, 2, 3, 4].map(i => res[i] || '–').join(' · ');
    openAncientModal('Case closed', '<div style="text-align:center;padding:6px 10px"><h2 style="font-family:Courier New;letter-spacing:.25em;color:#f1ece2;font-size:1.6rem;margin-bottom:8px">CASE CLOSED</h2><p style="font-family:Georgia;font-style:italic;font-size:1.05rem;color:#e7e5e4;max-width:600px;margin:0 auto 14px">Some numbers lie. Some people do too.<br>You checked both.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin:14px 0"><div class="ancient-carving-box"><div style="font-size:.75rem;color:#9ca3af">Score</div><div style="font-size:1.4rem;font-family:Georgia;color:#fda4af">' + gameState.score + '</div></div><div class="ancient-carving-box"><div style="font-size:.75rem;color:#9ca3af">Clues</div><div style="font-size:1.4rem;font-family:Georgia">5 / 5</div></div><div class="ancient-carving-box"><div style="font-size:.75rem;color:#9ca3af">Case Notes</div><div style="font-size:1.4rem;font-family:Georgia">' + gameState.codexUnlocked.length + ' / 8</div></div><div class="ancient-carving-box"><div style="font-size:.75rem;color:#9ca3af">Best ranks</div><div style="font-size:1.1rem;font-family:Courier New">' + ranks + '</div></div></div><div class="ancient-carving-box" style="border-color:#e11d48"><div class="carving-subtitle">Title earned</div><div style="font-size:1.1rem;color:#fecdd3;font-family:Courier New;letter-spacing:.15em">DATA DETECTIVE</div></div><p style="margin:14px 0 4px;font-size:.85rem;color:#9ca3af">Take the post-game quiz: Case Board → PLAYTEST.</p><div style="display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin-top:12px"><button class="hero-btn primary" id="tz-f-notes">CASE NOTES</button><button class="hero-btn" id="tz-f-board">CASE BOARD</button><button class="hero-btn" id="tz-f-new">NEW GAME</button></div><p style="margin-top:16px;font-family:Courier New;font-size:.8rem;color:#e11d48;letter-spacing:.3em;animation:tzb 1.4s infinite">DAY 1. AGAIN?</p></div>');
    $d('tz-f-notes').onclick = () => openCodexModal(); $d('tz-f-board').onclick = () => { closeAncientModal(); showWorldMap(); }; $d('tz-f-new').onclick = () => { resetGameState(); closeAncientModal(); showWorldMap(); };
  });
};
// bubble sits above Mira's head
updateAriaBubblePosition = function (sx, sy) { const b = $d('aria-bubble'); if (!b || b.style.display === 'none') return; const bh = b.offsetHeight || 110, gy = canvas.height * .77; b.style.left = Math.max(16, Math.min(innerWidth - 300, sx - 120)) + 'px'; b.style.top = Math.max(110, gy - tzH() - bh - 60) + 'px'; };
renderWorldMapSVG();

{ const b = $d('btn-open-codex'); if (b) b.innerHTML = '<span>✦</span> Case Notes (<span id="hud-codex-count">' + gameState.codexUnlocked.length + '</span>/8)'; const m = $d('btn-map-codex'); if (m) m.textContent = '✦ Case Notes'; }
const tzEvid = { 'Heat Crystal 1': "Jun's Keycard", 'Heat Crystal 2': 'Torn Photo', 'Cooling Key': 'Fuse', 'North Star Piece': 'Listener Letter', 'Southern Anchor Prism': 'Tape Reel', 'Star Dial': 'Studio Key', 'Cyan Magic Stone': 'Flashlight Batteries', 'Amber Magic Stone': 'Trail Map', 'Violet Magic Stone': "Jun's Scarf" };
{ const a = collectEmberCrystal, b = collectStarShard, c2 = collectWildsTotem;
  collectEmberCrystal = (i, n) => a(i, tzEvid[n] || n); collectStarShard = (i, n) => b(i, tzEvid[n] || n); collectWildsTotem = (i, n) => c2(i, tzEvid[n] || n); }
REALMS.forEach((r, i) => r.relicName = ["Jun's notebook", "Jun's phone", 'Proof the post is fake', 'Ping clusters', 'Sighting model'][i]);
gameState.inventory.forEach(it => { if (tzEvid[it.label]) it.label = tzEvid[it.label]; }); renderSatchel();
gzConfetti = function (n) {
  if (gzRM()) return; const cols = ['#efe8da', '#d6d3cb', '#e11d48', '#9ca3af', '#f5f1e8'];
  for (let i = 0; i < (n || 140) * .6; i++) gzFX.p.push({ x: Math.random() * innerWidth, y: -20 - Math.random() * 200, vx: (Math.random() - .5) * 2, vy: 1 + Math.random() * 2, r: Math.random() * 6.28, vr: (Math.random() - .5) * .15, w: 8 + Math.random() * 10, h: 6 + Math.random() * 8, c: cols[i % cols.length], life: 1.4 });
  if (!gzFX.run) { gzFX.run = true; requestAnimationFrame(gzFxLoop); }
};
tzMapG.push([/RETURN HOME/g, 'CASE BOARD']);
