# Echo Point — Playtest Evidence

> **SIMULATED SAMPLE EVIDENCE:** The participant responses, dates, quiz scores and gameplay metrics below are fictional examples created to demonstrate how completed playtest evidence could look. Replace them with actual observations and exported game data before submitting as real playtesting results.

---

## Participant 1 — Exploration and Gameplay

**Participant ID:** P01  
**Date:** 14 November 2026  
**Device / browser:** Laptop — Chrome

### Quiz scores (from PLAYTEST in the game)

| Pre-game quiz (/6) | Post-game quiz (/6) | Change |
|---:|---:|---:|
| 2 | 4 | +2 |

### Per chapter (sample gameplay data)

| Chapter | Completed? | Rewinds used | Hints | Time (s) | Rank |
|---|---|---:|---:|---:|---|
| 1 Rosie's Diner (mean/median) | Yes | 1 | 2 | 245 | B |
| 2 Basement (outliers) | Yes | 2 | 3 | 318 | C |
| 3 KECO Radio (correlation) | Yes | 1 | 2 | 286 | B |
| 4 Hollow Woods (K-means) | No | 1 | 2 | 354 | C |
| 5 Lighthouse (regression/overfitting) | No | 0 | 1 | 190 | — |

### Feedback

- **What was fun?** Exploring the rooms and collecting clues before solving the puzzles.
- **What was confusing?** Was initially unsure which items to collect and why the puzzle stayed locked. Needed some time to learn the walk, run, jump and interact controls.
- **Suggestion:** Make it clearer what to do next in each scene.
- **One thing learned:** The median is less affected by an unusually large value than the mean.
- **Would you play again?** Maybe.

### Observer notes

- **Where did they get stuck?** Collecting the right evidence before the puzzle unlocked, and learning the controls.
- **Did they discover the concept by playing, or did they read the answer?** Mostly through the activity, but used hints when unsure.

### Change made because of this feedback

- Added an evidence checklist and a visual glow on collectable items and notes.
- Added a control guide and a hint key (H) with contextual hints for each chapter.

---

## Participant 2 — Data Concepts and Learning

**Participant ID:** P02  
**Date:** 14 November 2026  
**Device / browser:** Windows laptop — Edge

### Quiz scores (from PLAYTEST in the game)

| Pre-game quiz (/6) | Post-game quiz (/6) | Change |
|---:|---:|---:|
| 3 | 5 | +2 |

### Per chapter (sample gameplay data)

| Chapter | Completed? | Rewinds used | Hints | Time (s) | Rank |
|---|---|---:|---:|---:|---|
| 1 Rosie's Diner (mean/median) | Yes | 0 | 1 | 198 | A |
| 2 Basement (outliers) | Yes | 1 | 2 | 272 | B |
| 3 KECO Radio (correlation) | Yes | 2 | 3 | 341 | C |
| 4 Hollow Woods (K-means) | Yes | 1 | 2 | 309 | B |
| 5 Lighthouse (regression/overfitting) | No | 1 | 2 | 365 | C |

### Feedback

- **What was fun?** Found the puzzles engaging, especially identifying unusual readings in the basement.
- **What was confusing?** Needed help understanding the IQR rule for outliers and why correlation is not causation.
- **Suggestion:** Give a simpler explanation after solving each puzzle.
- **One thing learned:** Two things changing together does not necessarily mean one causes the other.
- **Would you play again?** Yes.

### Observer notes

- **Where did they get stuck?** Chapter 2 (outliers) and Chapter 3 (correlation vs causation).
- **Did they discover the concept by playing, or did they read the answer?** Tried to solve the activities first, then used the explanations to confirm their understanding.

### Change made because of this feedback

- Added step-by-step hints for each puzzle.
- Expanded Case Notes with explanations, formulas and real-world examples.
- Added Mind Palace replays that show each concept using the player's own game data.

---

## Participant 3 — UI and Game Experience

**Participant ID:** P03  
**Date:** 15 November 2026  
**Device / browser:** Laptop — Chrome

### Quiz scores (from PLAYTEST in the game)

| Pre-game quiz (/6) | Post-game quiz (/6) | Change |
|---:|---:|---:|
| 1 | 4 | +3 |

### Per chapter (sample gameplay data)

| Chapter | Completed? | Rewinds used | Hints | Time (s) | Rank |
|---|---|---:|---:|---:|---|
| 1 Rosie's Diner (mean/median) | Yes | 1 | 1 | 226 | B |
| 2 Basement (outliers) | Yes | 1 | 2 | 291 | B |
| 3 KECO Radio (correlation) | Yes | 1 | 2 | 302 | B |
| 4 Hollow Woods (K-means) | Yes | 2 | 2 | 376 | C |
| 5 Lighthouse (regression/overfitting) | Yes | 1 | 2 | 402 | B |

### Feedback

- **What was fun?** Liked the thriller atmosphere, the animated characters and the rewind mechanic.
- **What was confusing?** Losing a rewind after a wrong choice was unclear at first.
- **Suggestion:** Provide an easier way to track completed chapters, clues and performance.
- **One thing learned:** A model that fits the training data too closely may not work well on new data.
- **Would you play again?** Yes.

### Observer notes

- **Where did they get stuck?** Understanding why a rewind was used and how the five chapters connect.
- **Did they discover the concept by playing, or did they read the answer?** Used the game activities and then checked the Case Notes for clarification.

### Change made because of this feedback

- Added the Case Board with clue-based chapter progress tracking.
- Showed what went wrong before each rewind, so the player can learn from the mistake.
- Added chapter ranks (S to C), a pre/post-game quiz, a feedback form and CSV/JSON export for playtest tracking.

---

## Conclusion

In this **simulated example**, playtesting feedback highlights areas where exploration, concept explanations and progress tracking could be improved. The sample quiz scores show improvement for all three fictional participants, while the chapter records illustrate how completion, hints, rewinds, time and ranks can be documented. These entries are placeholders, not results collected from actual players. Replace them with genuine participant feedback and exported game data before presenting the document as evidence of a real playtest.
