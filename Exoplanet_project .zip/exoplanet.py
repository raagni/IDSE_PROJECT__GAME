# IDSE Project - Part A
# Kepler KOI classification: CANDIDATE vs FALSE POSITIVE
# Team: M. Raagni (EC24B1106), V. Sarayu (EC24B1110), Anushree Chandra (EC24B1119)
#
# how to run:
#   pip install -r requirements.txt
#   python exoplanet.py --data q1_q17_dr25_koi_2026.11.07_06.58.13.csv
# all plots and result files get saved in the outputs/ folder

import argparse
import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # save plots to files instead of opening windows
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.base import clone
from sklearn.model_selection import GroupShuffleSplit, StratifiedGroupKFold, GridSearchCV, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import (accuracy_score, f1_score, roc_auc_score, roc_curve,
                             classification_report, confusion_matrix, ConfusionMatrixDisplay)

SEED = 42
np.random.seed(SEED)
sns.set_theme(style="whitegrid")

parser = argparse.ArgumentParser()
parser.add_argument("--data", default="q1_q17_dr25_koi_2026.11.07_06.58.13.csv")
parser.add_argument("--out", default="outputs")
args, _ = parser.parse_known_args()  # parse_known_args so it also works in colab/jupyter
out = args.out
os.makedirs(out, exist_ok=True)


# ---------------- LOADING DATA ----------------
df = pd.read_csv(args.data, comment="#")
print("data shape:", df.shape)
print(df.head())

print("\nduplicate rows:", df.duplicated().sum())
print("unique stars:", df['kepid'].nunique())
print("stars with more than 1 KOI:", (df['kepid'].value_counts() > 1).sum())
print("\ntarget distribution:\n", df['koi_pdisposition'].value_counts())

# the 8 physical features we picked
# we did NOT use koi_score, koi_fpflag_* or koi_disposition because they come from
# the same vetting step that makes our target -> that would be target leakage
# also left out id columns and the _err columns (they mostly repeat the main values)
features = ['koi_period', 'koi_duration', 'koi_depth', 'koi_model_snr',
            'koi_impact', 'koi_prad', 'koi_steff', 'koi_srad']

missing = df[features].isnull().sum()
print("\nmissing values:\n", missing)
# turns out its the same 59 rows missing all 6 of these columns
print("rows missing depth,snr,impact,prad,steff,srad together:",
      df[features[2:]].isnull().all(axis=1).sum())


# ---------------- FEATURE ENGINEERING ----------------
# 1. how many KOIs are on the same star. multi planet systems are mostly real planets
df['n_koi_on_star'] = df.groupby('kepid')['kepid'].transform('count')
# 2. transit duration should go roughly like period^(1/3), so if this ratio is weird
#    it could be an eclipsing binary
df['duration_ratio'] = df['koi_duration'] / np.cbrt(df['koi_period'])
# 3. planet radius / star radius (109.1 earth radii = 1 solar radius)
#    if this is big (~0.3 or more) its basically a star not a planet
df['radius_ratio'] = df['koi_prad'] / (df['koi_srad'] * 109.1)

new_features = ['n_koi_on_star', 'duration_ratio', 'radius_ratio']
all_features = features + new_features

# these are right skewed so we take log for plots and for logistic regression
skewed = ['koi_period', 'koi_duration', 'koi_depth', 'koi_model_snr', 'koi_prad',
          'koi_srad', 'duration_ratio', 'radius_ratio']


# ---------------- EDA PLOTS ----------------
# histograms of each feature
fig, axes = plt.subplots(4, 2, figsize=(13, 14))
axes = axes.flatten()
for i, f in enumerate(features):
    sns.histplot(df[f].dropna(), bins=50, ax=axes[i])
    axes[i].set_title(f"{f} (skew = {df[f].skew():.1f})")
plt.tight_layout()
plt.savefig(f"{out}/01_raw_distributions.png", dpi=120)
plt.close()
# all of them are very right skewed

# same thing but split by class and on log scale, easier to compare
fig, axes = plt.subplots(4, 2, figsize=(13, 14))
axes = axes.flatten()
for i, f in enumerate(features):
    temp = df[[f, 'koi_pdisposition']].dropna()
    if f in skewed:
        temp = temp[temp[f] > 0]
    sns.histplot(temp, x=f, hue='koi_pdisposition', bins=50, element="step",
                 stat="density", common_norm=False, log_scale=(f in skewed), ax=axes[i])
    axes[i].set_title(f)
plt.tight_layout()
plt.savefig(f"{out}/02_class_distributions.png", dpi=120)
plt.close()
# planet radius separates the classes the most. false positives have a second peak
# around 20-100 earth radii which is star size

# correlation heatmap (spearman + log so outliers dont dominate)
temp = df[all_features].copy()
for f in skewed:
    temp[f] = np.log1p(temp[f].clip(lower=0))
plt.figure(figsize=(10, 8))
sns.heatmap(temp.corr(method='spearman'), annot=True, fmt=".2f", cmap="vlag", center=0, square=True)
plt.title("Spearman correlation of features")
plt.tight_layout()
plt.savefig(f"{out}/03_correlation.png", dpi=120)
plt.close()

# label share vs number of KOIs on the star
ct = pd.crosstab(df['n_koi_on_star'].clip(upper=4), df['koi_pdisposition'], normalize='index')
ax = ct.plot(kind='bar', stacked=True, figsize=(7, 4), color=["#4C72B0", "#DD8452"])
ax.set_xlabel("KOIs on the same star (4 = 4 or more)")
ax.set_ylabel("share")
ax.set_title("Multi-planet systems are mostly CANDIDATEs")
plt.tight_layout()
plt.savefig(f"{out}/04_multiplicity.png", dpi=120)
plt.close()


# ---------------- OUTLIERS (IQR) ----------------
outlier_results = []
for f in features:
    Q1 = df[f].quantile(0.25)
    Q3 = df[f].quantile(0.75)
    IQR = Q3 - Q1
    lower_limit = Q1 - 1.5 * IQR
    upper_limit = Q3 + 1.5 * IQR
    count = ((df[f] < lower_limit) | (df[f] > upper_limit)).sum()
    outlier_results.append({'feature': f, 'outliers': int(count),
                            'pct': round(count / df[f].notna().sum() * 100, 1)})
outlier_df = pd.DataFrame(outlier_results)
print("\nOUTLIER SUMMARY:")
print(outlier_df.to_string(index=False))
# we are NOT removing outliers. huge radius / very deep transits are real eclipsing
# binaries, they are actually the easiest false positives. removing them would make
# the results look better than they really are


# ---------------- TRAIN / TEST SPLIT ----------------
X = df[all_features]
y = (df['koi_pdisposition'] == 'CANDIDATE').astype(int)   # 1 = candidate, 0 = false positive
groups = df['kepid']

# split by star (kepid) so planets of the same star dont end up in both train and test
gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=SEED)
train_idx, test_idx = next(gss.split(X, y, groups))
X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
groups_train = groups.iloc[train_idx]
print("\ntrain size:", len(train_idx), " test size:", len(test_idx))
print("stars in both train and test:", len(set(groups.iloc[train_idx]) & set(groups.iloc[test_idx])))

# 5 fold CV, also grouped by star
cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)


# ---------------- MODELS ----------------
def log_transform(X):
    X = X.copy()
    for f in skewed:
        X[f] = np.log1p(X[f].clip(lower=0))
    return X

# everything (filling missing values, log, scaling) is inside a pipeline
# so it only learns from the training folds -> no data leakage
lr_pipe = Pipeline([
    ('log', FunctionTransformer(log_transform)),
    ('impute', SimpleImputer(strategy='median')),
    ('scale', StandardScaler()),
    ('clf', LogisticRegression(max_iter=2000, random_state=SEED))
])
rf_pipe = Pipeline([
    ('impute', SimpleImputer(strategy='median')),
    ('clf', RandomForestClassifier(random_state=SEED, n_jobs=-1))
])
# xgboost can handle NaN by itself so no imputer needed
xgb_pipe = Pipeline([
    ('clf', XGBClassifier(eval_metric='logloss', random_state=SEED, n_jobs=-1))
])

models = {
    "Logistic Regression (baseline)": (lr_pipe, {'clf__C': [0.01, 0.1, 1, 10]}),
    "Random Forest": (rf_pipe, {'clf__n_estimators': [300],
                                'clf__max_depth': [None, 12],
                                'clf__min_samples_leaf': [1, 5]}),
    "XGBoost": (xgb_pipe, {'clf__n_estimators': [300, 600],
                           'clf__max_depth': [3, 5],
                           'clf__learning_rate': [0.05, 0.1]}),
}

results = []
trained = {}
for name, (pipe, params) in models.items():
    print(f"\n========== {name} ==========")
    # grid search with CV on train set only
    grid = GridSearchCV(pipe, params, cv=cv, scoring='roc_auc', n_jobs=-1)
    grid.fit(X_train, y_train, groups=groups_train)
    best = grid.best_estimator_
    trained[name] = best
    print("best params:", grid.best_params_)

    cv_res = cross_validate(clone(best), X_train, y_train, groups=groups_train, cv=cv,
                            scoring=['accuracy', 'f1', 'roc_auc'])
    print(f"CV accuracy: {cv_res['test_accuracy'].mean():.4f} (+/- {cv_res['test_accuracy'].std():.4f})")
    print(f"CV AUC: {cv_res['test_roc_auc'].mean():.4f}")

    # test set
    prob = best.predict_proba(X_test)[:, 1]
    pred = (prob >= 0.5).astype(int)
    print(f"Test accuracy: {accuracy_score(y_test, pred):.4f}")
    print(classification_report(y_test, pred, target_names=['FALSE POSITIVE', 'CANDIDATE'], digits=3))

    results.append({
        'model': name,
        'best_params': grid.best_params_,
        'cv_accuracy': cv_res['test_accuracy'].mean(),
        'cv_accuracy_sd': cv_res['test_accuracy'].std(),
        'cv_f1': cv_res['test_f1'].mean(),
        'cv_auc': cv_res['test_roc_auc'].mean(),
        'test_accuracy': accuracy_score(y_test, pred),
        'test_f1': f1_score(y_test, pred),
        'test_auc': roc_auc_score(y_test, prob),
    })

results_df = pd.DataFrame(results)
print("\n========== MODEL COMPARISON ==========")
print(results_df.drop(columns='best_params').round(4).to_string(index=False))
results_df.to_csv(f"{out}/model_comparison.csv", index=False)


# ---------------- EVALUATION PLOTS ----------------
# ROC curves for all 3 models
plt.figure(figsize=(6, 5))
for name, model in trained.items():
    prob = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, prob)
    plt.plot(fpr, tpr, label=f"{name} (AUC {roc_auc_score(y_test, prob):.3f})")
plt.plot([0, 1], [0, 1], 'k--', lw=1)
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
plt.title("ROC curves on test set")
plt.legend(loc='lower right')
plt.tight_layout()
plt.savefig(f"{out}/05_roc.png", dpi=120)
plt.close()

# pick the best model using CV AUC (not test score, so test stays fair)
best_name = results_df.sort_values('cv_auc', ascending=False).iloc[0]['model']
best_model = trained[best_name]
print("\nbest model:", best_name)

prob = best_model.predict_proba(X_test)[:, 1]
pred = (prob >= 0.5).astype(int)

ConfusionMatrixDisplay(confusion_matrix(y_test, pred),
                       display_labels=['FALSE POS.', 'CANDIDATE']).plot(cmap='Blues', values_format='d')
plt.title(f"Confusion matrix: {best_name}")
plt.tight_layout()
plt.savefig(f"{out}/06_confusion_matrix.png", dpi=120)
plt.close()

importance = pd.Series(best_model.named_steps['clf'].feature_importances_, index=all_features).sort_values()
importance.plot(kind='barh', figsize=(7, 5), color="#4C72B0")
plt.title(f"Feature importance: {best_name}")
plt.tight_layout()
plt.savefig(f"{out}/07_feature_importance.png", dpi=120)
plt.close()


# ---------------- ERROR ANALYSIS ----------------
test_df = df.iloc[test_idx].copy()
test_df['true'] = y_test.values
test_df['pred'] = pred
test_df['outcome'] = 'TN'
test_df.loc[(test_df['true'] == 1) & (test_df['pred'] == 1), 'outcome'] = 'TP'
test_df.loc[(test_df['true'] == 0) & (test_df['pred'] == 1), 'outcome'] = 'FP'
test_df.loc[(test_df['true'] == 1) & (test_df['pred'] == 0), 'outcome'] = 'FN'

# median values for each outcome, to see what the mistakes look like
err = test_df.groupby('outcome')[['koi_model_snr', 'koi_depth', 'koi_prad', 'koi_period',
                                  'koi_impact', 'n_koi_on_star']].median().round(2)
err['count'] = test_df['outcome'].value_counts()
print("\nERROR ANALYSIS (medians):\n", err)
err.to_csv(f"{out}/error_analysis.csv")

# compare with the final archive label (only for analysis, not used in training)
final = pd.crosstab(test_df['outcome'], test_df['koi_disposition'])
print("\noutcome vs final archive label:\n", final)
final.to_csv(f"{out}/errors_vs_final_disposition.csv")

# which fp flags do the false positives have? (again only for analysis)
flags = ['koi_fpflag_nt', 'koi_fpflag_ss', 'koi_fpflag_co', 'koi_fpflag_ec']
flag_rates = test_df[test_df['true'] == 0].groupby('outcome')[flags].mean().round(3)
print("\nfp flag rates (FP = ones we missed, TN = ones we caught):\n", flag_rates)
flag_rates.to_csv(f"{out}/fp_flag_rates.csv")
# most of the missed ones have the centroid offset flag -> background binaries
# we cant catch those without pixel level data

with open(f"{out}/summary.json", "w") as fh:
    json.dump({'best_model': best_name, 'results': results,
               'outliers': outlier_df.to_dict('records')}, fh, indent=2, default=str)

print("\ndone! everything is saved in", out)
