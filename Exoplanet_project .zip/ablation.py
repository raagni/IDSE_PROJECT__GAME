# ablation study - checking if our new features and the split by star actually helped
# run after exoplanet.py:  python ablation.py --data q1_q17_dr25_koi_2026.11.07_06.58.13.csv

import argparse
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedGroupKFold, StratifiedKFold
from xgboost import XGBClassifier

SEED = 42
parser = argparse.ArgumentParser()
parser.add_argument("--data", default="q1_q17_dr25_koi_2026.11.07_06.58.13.csv")
args, _ = parser.parse_known_args()
os.makedirs("outputs", exist_ok=True)

df = pd.read_csv(args.data, comment="#")

# same features as in exoplanet.py
df['n_koi_on_star'] = df.groupby('kepid')['kepid'].transform('count')
df['duration_ratio'] = df['koi_duration'] / np.cbrt(df['koi_period'])
df['radius_ratio'] = df['koi_prad'] / (df['koi_srad'] * 109.1)

features = ['koi_period', 'koi_duration', 'koi_depth', 'koi_model_snr',
            'koi_impact', 'koi_prad', 'koi_steff', 'koi_srad']
all_features = features + ['n_koi_on_star', 'duration_ratio', 'radius_ratio']

y = (df['koi_pdisposition'] == 'CANDIDATE').astype(int)
groups = df['kepid']

# best xgboost settings from the grid search
def make_model():
    return XGBClassifier(n_estimators=300, max_depth=5, learning_rate=0.05,
                         random_state=SEED, eval_metric='logloss')

group_cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
random_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

tests = [
    ("8 raw features", features),
    ("raw + n_koi_on_star", features + ['n_koi_on_star']),
    ("raw + ratios only", features + ['duration_ratio', 'radius_ratio']),
    ("all 11 features", all_features),
]

rows = []
for label, cols in tests:
    auc = cross_val_score(make_model(), df[cols], y, groups=groups, cv=group_cv, scoring='roc_auc')
    acc = cross_val_score(make_model(), df[cols], y, groups=groups, cv=group_cv, scoring='accuracy')
    rows.append([label, "by star", auc.mean(), acc.mean()])

# same thing with a normal random split to compare
auc = cross_val_score(make_model(), df[all_features], y, cv=random_cv, scoring='roc_auc')
acc = cross_val_score(make_model(), df[all_features], y, cv=random_cv, scoring='accuracy')
rows.append(["all 11 features", "random rows", auc.mean(), acc.mean()])

result = pd.DataFrame(rows, columns=['features', 'CV split', 'AUC', 'accuracy']).round(4)
print(result.to_string(index=False))
result.to_csv("outputs/ablation.csv", index=False)
