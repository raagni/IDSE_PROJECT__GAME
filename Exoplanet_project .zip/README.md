# Classifying Kepler Objects of Interest: Candidate vs False Positive

Can we tell a real planet-transit signal from a false alarm using only the
physical properties of the transit and its host star?

## Data
NASA Exoplanet Archive, Kepler Q1–Q17 DR25 KOI table
(https://exoplanetarchive.ipac.caltech.edu, table `q1_q17_dr25_koi`).
8,054 KOIs on 6,923 stars, 49 columns. Target: `koi_pdisposition`
(CANDIDATE 4,034 / FALSE POSITIVE 4,020).

Download the CSV from the archive and put it in this folder (or pass `--data`).

## Run
```bash
pip install -r requirements.txt
python exoplanet.py --data q1_q17_dr25_koi_2026.11.07_06.58.13.csv
python ablation.py          # optional: feature-engineering & split ablation
```
Runtime is about 1–2 minutes. All random seeds are fixed (`SEED = 42`).

## Outputs (`outputs/`)
| File | Content |
|---|---|
| `01_raw_distributions.png` | Histograms of the 8 raw features |
| `02_class_distributions.png` | Per-class distributions (log scale) |
| `03_correlation.png` | Spearman correlation heatmap |
| `04_multiplicity.png` | Label share by number of KOIs on the star |
| `05_roc.png` | ROC curves of all three models |
| `06_confusion_matrix.png` | Confusion matrix of the best model |
| `07_feature_importance.png` | Feature importance of the best model |
| `model_comparison.csv` | CV and test metrics for all models |
| `error_analysis.csv`, `errors_vs_final_disposition.csv`, `fp_flag_rates.csv` | Error analysis |
| `ablation.csv` | Effect of engineered features and of split strategy |

## Method in brief
- 11 features: 8 transit/stellar measurements + 3 engineered (KOIs on the same
  star, duration / period^(1/3), planet-to-star radius ratio).
- Leakage columns excluded (`koi_score`, `koi_fpflag_*`, `koi_disposition`).
- 80/20 train/test split **grouped by star** (`kepid`), 5-fold
  StratifiedGroupKFold CV with grid search on the training set only.
- All preprocessing (imputation, log transform, scaling) inside sklearn Pipelines.
- Models: Logistic Regression (baseline), Random Forest, XGBoost.

## Results (held-out test set)
| Model | CV accuracy | CV AUC | Test accuracy | Test AUC |
|---|---|---|---|---|
| Logistic Regression | 0.827 | 0.897 | 0.808 | 0.879 |
| Random Forest | 0.869 | 0.941 | 0.863 | 0.935 |
| **XGBoost** | **0.871** | **0.942** | **0.870** | **0.932** |
